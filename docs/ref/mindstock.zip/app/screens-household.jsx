// screens-household.jsx — multi-household: switcher, create, join-by-code, header pill, empty state.
// A user can belong to several households and switch between them, or have none (settings-only).

// ── small tappable pill that opens the switcher (used in headers) ──
function HouseholdPill({ name, onClick, count }) {
  const T = useTheme();
  const [press, setPress] = React.useState(false);
  return (
    <button onClick={onClick}
      onPointerDown={() => setPress(true)} onPointerUp={() => setPress(false)} onPointerLeave={() => setPress(false)}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '7px 10px 7px 8px', borderRadius: 99,
        background: T.surface, border: `1px solid ${T.line}`, cursor: 'pointer', maxWidth: 220, boxShadow: T.shadow.sm,
        transition: 'transform .14s', transform: press ? 'scale(0.96)' : 'scale(1)' }}>
      <span style={{ width: 24, height: 24, borderRadius: 8, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
        <Icon name="home" size={14} />
      </span>
      <span style={{ font: `700 13.5px/1 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
      {count != null && <span style={{ font: `600 11px/1 var(--f)`, color: T.faint, flexShrink: 0, whiteSpace: 'nowrap' }}>{count}人</span>}
      <Icon name="chevD" size={15} style={{ color: T.faint, flexShrink: 0 }} />
    </button>
  );
}

// ── switcher sheet: list of households + create / join actions ──
function HouseholdSwitcher({ open, onClose, store, onCreate, onJoin }) {
  const T = useTheme();
  const list = store.households;
  const choose = (id) => { store.switchHousehold(id); onClose(); };
  return (
    <Sheet open={open} onClose={onClose} title="世帯を切り替え" maxW={460}>
      <div style={{ font: `400 13.5px/1.6 var(--f)`, color: T.sub, margin: '-6px 0 16px' }}>
        参加している世帯から選んで切り替えられます。いくつでも持てます。
      </div>

      {list.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9, marginBottom: 16 }}>
          {list.map(h => {
            const active = h.id === store.activeId;
            const me = h.members.find(m => m.you);
            const role = ROLES[me ? me.role : 'member'];
            return (
              <button key={h.id} onClick={() => choose(h.id)} style={{
                display: 'flex', alignItems: 'center', gap: 13, padding: '13px 14px', borderRadius: T.radius.lg, cursor: 'pointer',
                textAlign: 'left', width: '100%',
                background: active ? T.accentSoft : T.surface,
                border: `1.5px solid ${active ? T.accent : T.lineSoft}`, boxShadow: active ? 'none' : T.shadow.sm }}>
                <span style={{ width: 44, height: 44, borderRadius: 13, background: active ? T.accent : T.surface2, color: active ? T.onAccent : T.sub, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                  <Icon name="home" size={22} />
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `700 15.5px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{h.name}</div>
                  <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, font: `500 11.5px/1 var(--f)`, color: T.faint, marginTop: 6 }}>
                    <Icon name="users" size={13} />{h.members.length}人
                    <span style={{ color: T.line }}>·</span>
                    <Icon name={role.icon} size={12} style={{ color: me && me.role === 'owner' ? T.accent : T.faint }} />{role.label}
                  </div>
                </div>
                <span style={{ width: 24, height: 24, borderRadius: 99, flexShrink: 0, display: 'grid', placeItems: 'center',
                  border: `2px solid ${active ? T.accent : T.line}`, background: active ? T.accent : 'transparent', color: T.onAccent }}>
                  {active && <Icon name="check" size={14} stroke={2.8} />}
                </span>
              </button>
            );
          })}
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
        <SwitcherAction icon="add" label="新しい世帯をつくる" sub="空の在庫から始めます" onClick={onCreate} accent />
        <SwitcherAction icon="link" label="招待コードで参加" sub="家族や同居人の世帯に加わる" onClick={onJoin} />
      </div>
    </Sheet>
  );
}

function SwitcherAction({ icon, label, sub, onClick, accent }) {
  const T = useTheme();
  return (
    <button onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 13, padding: '13px 14px', borderRadius: T.radius.lg, cursor: 'pointer',
      textAlign: 'left', width: '100%', background: T.surface, border: `1px dashed ${accent ? T.accent : T.line}` }}>
      <span style={{ width: 40, height: 40, borderRadius: 12, background: accent ? T.accentSoft : T.surface2, color: accent ? T.accent : T.sub, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
        <Icon name={icon} size={20} />
      </span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: `700 14.5px/1.2 var(--f)`, color: accent ? T.accent : T.ink }}>{label}</div>
        <div style={{ font: `500 11.5px/1.3 var(--f)`, color: T.faint, marginTop: 4 }}>{sub}</div>
      </div>
      <Icon name="chevR" size={17} style={{ color: T.faint, flexShrink: 0 }} />
    </button>
  );
}

// ── create a brand-new (empty) household ──
function CreateHouseholdSheet({ open, onClose, store, displayName, onAfter }) {
  const T = useTheme();
  const [name, setName] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  React.useEffect(() => { if (open) { setName(''); setBusy(false); } }, [open]);
  const create = () => {
    setBusy(true);
    setTimeout(() => {
      store.createHousehold(name.trim() || 'あたらしい世帯', { myName: displayName });
      onAfter && onAfter();
      onClose();
    }, 500);
  };
  return (
    <Sheet open={open} onClose={onClose} title="世帯をつくる" maxW={460}>
      <div style={{ font: `400 13.5px/1.6 var(--f)`, color: T.sub, margin: '-6px 0 18px' }}>
        在庫を共有する単位です。あなたがオーナーになります。あとから家族を招待できます。
      </div>
      <div style={{ width: 52, height: 52, borderRadius: 16, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', marginBottom: 16 }}>
        <Icon name="home" size={26} />
      </div>
      <input value={name} maxLength={50} autoFocus onChange={e => setName(e.target.value)} placeholder="例: 別荘の在庫"
        style={{ width: '100%', height: 56, borderRadius: 16, border: `1.5px solid ${name ? T.accent : T.line}`, background: T.surface,
          padding: '0 18px', font: `600 17px/1 var(--f)`, color: T.ink, boxSizing: 'border-box', outline: 'none', boxShadow: T.shadow.sm, transition: 'border-color .2s' }} />
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12, marginBottom: 22 }}>
        {['わたしの家', '実家', '別荘', 'オフィス'].map(c => (
          <button key={c} onClick={() => setName(c)} style={{ font: `600 13px/1 var(--f)`, color: T.sub, background: T.surface, border: `1px solid ${T.line}`, padding: '9px 13px', borderRadius: 99, cursor: 'pointer', whiteSpace: 'nowrap' }}>{c}</button>
        ))}
      </div>
      <Btn full size="lg" disabled={busy} icon={busy ? undefined : 'home'} onClick={create}>{busy ? '作成中…' : 'この世帯をつくる'}</Btn>
    </Sheet>
  );
}

// ── join an existing household by code (demo: joins a seeded household as a member) ──
function JoinCodeSheet({ open, onClose, store, displayName, onAfter }) {
  const T = useTheme();
  const [code, setCode] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  React.useEffect(() => { if (open) { setCode(''); setBusy(false); } }, [open]);
  const ok = code.trim().length >= 4;
  const join = () => {
    if (!ok) return;
    setBusy(true);
    setTimeout(() => {
      store.joinHousehold(displayName || 'あなた', { name: 'ゆい', initial: 'ゆ', color: USERS.yui.color }, 'member', 'ゆいの家');
      onAfter && onAfter();
      onClose();
    }, 700);
  };
  return (
    <Sheet open={open} onClose={onClose} title="招待コードで参加" maxW={460}>
      <div style={{ font: `400 13.5px/1.6 var(--f)`, color: T.sub, margin: '-6px 0 18px' }}>
        家族や同居人から受け取った6桁のコードを入力してください。
      </div>
      <input value={code} maxLength={6} autoFocus
        onChange={e => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))}
        placeholder="K7M2PQ"
        style={{ width: '100%', height: 64, borderRadius: 16, border: `1.5px solid ${code ? T.accent : T.line}`, background: T.surface,
          padding: '0 18px', font: `700 26px/1 ui-monospace, SFMono-Regular, Menlo, monospace`, letterSpacing: '0.22em',
          color: T.ink, boxSizing: 'border-box', outline: 'none', textAlign: 'center', boxShadow: T.shadow.sm, transition: 'border-color .2s' }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, font: `400 12px/1.5 var(--f)`, color: T.faint, margin: '12px 2px 22px' }}>
        <Icon name="spark" size={14} style={{ color: T.accent, flexShrink: 0 }} />
        <span>デモ：どのコードでも「ゆいの家」に参加します。</span>
      </div>
      <Btn full size="lg" disabled={!ok || busy} icon={busy ? undefined : 'link'} onClick={join}>{busy ? '参加中…' : '参加する'}</Btn>
    </Sheet>
  );
}

// ── empty state shown in settings when you belong to no household ──
function NoHouseholdCard({ onCreate, onJoin }) {
  const T = useTheme();
  return (
    <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, padding: 22, marginBottom: 16 }}>
      <div style={{ width: 52, height: 52, borderRadius: 16, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', marginBottom: 16 }}>
        <Icon name="home" size={26} />
      </div>
      <div style={{ font: `700 17px/1.35 var(--f)`, color: T.ink }}>まだ世帯がありません</div>
      <p style={{ font: `400 13.5px/1.65 var(--f)`, color: T.sub, margin: '8px 0 18px' }}>
        在庫の管理をはじめるには、世帯をつくるか、招待コードで参加してください。
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn full size="lg" icon="home" onClick={onCreate}>世帯をつくる</Btn>
        <Btn full size="lg" variant="ghost" icon="link" onClick={onJoin}>招待コードで参加</Btn>
      </div>
    </div>
  );
}

Object.assign(window, { HouseholdPill, HouseholdSwitcher, CreateHouseholdSheet, JoinCodeSheet, NoHouseholdCard });
