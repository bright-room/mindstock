// data.jsx — mock catalog, products, history, and the app state hook.

const ICONS_BY_CAT = {
  soap: 'drop', paper: 'paper', food: 'egg', drink: 'bottle',
  clean: 'bottle', staple: 'box', battery: 'bolt', misc: 'box',
};

// seed products (世帯の在庫)
const SEED = [
  { id: 'p1', name: 'キレイキレイ 泡ハンドソープ', unit: '本', cat: 'soap',    qty: 2, min: 1, daily: 0.10, icon: 'drop' },
  { id: 'p2', name: 'トイレットペーパー 12ロール', unit: 'パック', cat: 'paper', qty: 1, min: 1, daily: 0.18, icon: 'paper' },
  { id: 'p3', name: '牛乳 1L',                    unit: '本', cat: 'drink',   qty: 0, min: 2, daily: 0.5,  icon: 'bottle' },
  { id: 'p4', name: '卵 10個入り',                unit: 'パック', cat: 'food', qty: 1, min: 1, daily: 0.3,  icon: 'egg' },
  { id: 'p5', name: '食器用洗剤 ジョイ',          unit: '本', cat: 'clean',   qty: 3, min: 1, daily: 0.05, icon: 'bottle' },
  { id: 'p6', name: 'お米 5kg',                   unit: '袋', cat: 'staple',  qty: 1, min: 1, daily: 0.07, icon: 'box' },
  { id: 'p7', name: 'ボックスティッシュ 5箱',     unit: 'パック', cat: 'paper', qty: 2, min: 1, daily: 0.12, icon: 'paper' },
  { id: 'p8', name: 'シャンプー メリット',        unit: '本', cat: 'soap',    qty: 1, min: 1, daily: 0.06, icon: 'drop' },
  { id: 'p9', name: '醤油 こいくち',              unit: '本', cat: 'food',    qty: 0, min: 1, daily: 0.04, icon: 'salt' },
  { id: 'p10', name: '単3 アルカリ乾電池',        unit: 'パック', cat: 'battery', qty: 1, min: 2, daily: 0.02, icon: 'bolt' },
  { id: 'p11', name: '洗濯洗剤 アタック',         unit: '本', cat: 'clean',   qty: 2, min: 1, daily: 0.05, icon: 'bottle' },
  { id: 'p12', name: 'サランラップ 30cm',         unit: '本', cat: 'misc',    qty: 3, min: 1, daily: 0.03, icon: 'box' },
];

// catalog search pool (全世帯共有カタログ — future external API feel)
// jan: 商品マスタに紐づく JAN コード（架空・13桁フォーマット）
const CATALOG = [
  { id: 'c20', name: 'ファブリーズ 消臭スプレー', unit: '本', icon: 'bottle', shared: 312, jan: '4902430735996' },
  { id: 'c21', name: 'キッチンペーパー 4ロール', unit: 'パック', icon: 'paper', shared: 540, jan: '4901750901234' },
  { id: 'c22', name: 'ハンドクリーム ニベア',    unit: '本', icon: 'drop', shared: 88,  jan: '4901301352057' },
  { id: 'c23', name: 'マヨネーズ キユーピー',    unit: '本', icon: 'salt', shared: 421, jan: '4901577071010' },
  { id: 'c24', name: '麦茶パック',               unit: '箱', icon: 'box', shared: 233, jan: '4901085123459' },
  { id: 'c25', name: 'ゴミ袋 45L',               unit: 'パック', icon: 'box', shared: 610, jan: '4902011765432' },
];

// カメラがデモ用に「読み取る」JAN の並び（タップ／自動でこの順に検出）
// 在庫にある商品 → マスタにあるが未採用 → マスタに無い新商品、を一巡できる構成
const DEMO_SCANS = [
  '4901750901234', // キッチンペーパー（自社マスタにある）
  '4912345678904', // 自社マスタに無い → 外部APIで「お~いお茶」がヒット
  '4988888888885', // どこにも無い → 名前を手入力
  '4901577071010', // マヨネーズ（自社マスタにある）
];
const catalogByJan = (jan) => CATALOG.find(c => c.jan === jan) || null;
const onlyDigits = (s) => (s || '').replace(/\D/g, '');

// バックエンドが楽天/Yahoo! ショッピング API で JAN から取得する想定の「外部商品DB」モック。
// 自社の大元マスタ(CATALOG)に無くても、ここに当たれば商品名・標準単位を自動補完できる。
// （実機では: DB照合 → 無ければAPI取得 → DBへ保存、の2段構え）
const EXTERNAL_DB = {
  '4912345678904': { name: 'お~いお茶 緑茶 2L', unit: '本', source: '楽天市場' },
  '4901085140130': { name: '伊右衛門 緑茶 600ml', unit: '本', source: 'Yahoo!ショッピング' },
  '4902102072670': { name: 'コカ・コーラ 500ml', unit: '本', source: '楽天市場' },
  '4901301231123': { name: 'アタックゼロ 詰替', unit: '袋', source: 'Yahoo!ショッピング' },
};
// API結果のシミュレーション（null = どこにも無い → 手入力へ）
const lookupJan = (jan) => EXTERNAL_DB[jan] || null;

const USERS = {
  me:   { id: 'u1', name: 'あなた', initial: 'あ', color: 'oklch(0.62 0.13 41)' },
  yui:  { id: 'u2', name: 'ゆい',   initial: 'ゆ', color: 'oklch(0.58 0.12 268)' },
};

// household roles
const ROLES = {
  owner:  { key: 'owner',  label: 'オーナー',   short: 'オーナー', icon: 'crown', desc: '世帯の管理者。メンバーや権限を変更できます。' },
  member: { key: 'member', label: '編集できる', short: '編集可',   icon: 'pencil', desc: '在庫の補充・消費・商品の追加ができます。' },
  viewer: { key: 'viewer', label: '閲覧のみ',   short: '閲覧のみ', icon: 'eye',   desc: '在庫を見ることだけできます。記録は変更できません。' },
};

// short readable join code — avoids ambiguous chars (0/O, 1/I)
function genCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}
const joinLink = (code) => `mindstock.app/join/${code}`;

function statusOf(p) {
  if (p.qty <= 0) return 'out';
  if (p.qty <= p.min) return 'low';
  return 'ok';
}
// 買い物リストに載るか：閾値割れ（自動）または手動フラグ
function onShoppingList(p) { return statusOf(p) !== 'ok' || !!p.wanted; }
function predictDays(p) {
  if (!p.daily || p.daily <= 0) return null;
  return Math.round(p.qty / p.daily);
}

// seed history for one product (newest first)
function seedHistory(p) {
  const now = Date.now();
  const D = 86400000;
  const base = [
    { id: p.id + 'h1', kind: 'consume', qty: 1, occurredAt: now - 1 * D, by: 'me',  note: '', corrected: false },
    { id: p.id + 'h2', kind: 'replenish', qty: 2, occurredAt: now - 4 * D, by: 'me', note: 'まとめ買い', corrected: false },
    { id: p.id + 'h3', kind: 'consume', qty: 1, occurredAt: now - 7 * D, by: 'yui', note: '', corrected: true, correctedQty: 1 },
    { id: p.id + 'h4', kind: 'replenish', qty: 1, occurredAt: now - 14 * D, by: 'me', note: '', corrected: false },
  ];
  return base;
}

function relTime(ts) {
  const diff = Date.now() - ts;
  const h = Math.floor(diff / 3600000);
  if (h < 1) return 'たった今';
  if (h < 24) return `${h}時間前`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}日前`;
  const date = new Date(ts);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}
function fmtDate(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
}

// ── build a household object ──
// seedProducts: fill with the demo inventory (rich) vs empty (brand-new)
// asMember: you join an existing household (inviter is owner, you are member)
function buildHousehold(id, { name, seedProducts = false, asMember = false, inviter = null, myName = 'あなた', myRole = 'member' } = {}) {
  const products = seedProducts ? SEED.map(p => ({ ...p })) : [];
  const history = {};
  if (seedProducts) SEED.forEach(p => { history[p.id] = seedHistory(p); });
  const nm = myName || 'あなた';
  const initial = nm[0] || 'あ';
  let members;
  if (asMember) {
    const inv = inviter || { name: 'ゆい', initial: 'ゆ', color: USERS.yui.color };
    members = [
      { id: 'u2', name: inv.name, initial: inv.initial, color: inv.color, role: 'owner', joinedAt: Date.now() - 40 * 86400000 },
      { id: 'u1', name: nm, initial, color: USERS.me.color, role: myRole || 'member', you: true, joinedAt: Date.now() },
    ];
  } else {
    members = [{ id: 'u1', name: nm, initial, color: USERS.me.color, role: 'owner', you: true, joinedAt: Date.now() }];
  }
  return { id, name: name || 'わたしの家', members, invite: null, products, history };
}

let _hhSeq = 0;
const newHHId = () => 'hh' + Date.now() + '_' + (_hhSeq++);

// central app state — a user can belong to multiple households; one is active (or none)
function useStore() {
  const [households, setHouseholds] = React.useState([]); // start with none (fresh account)
  const [activeId, setActiveId] = React.useState(null);
  const [toast, setToast] = React.useState(null);

  const active = households.find(h => h.id === activeId) || null;
  const allProducts = active ? active.products : [];
  const products = allProducts.filter(p => !p.archived);          // 在庫・買い物・マスタに出る現役商品
  const archivedProducts = allProducts.filter(p => p.archived);   // アーカイブ済み（復元可・設定/履歴は保持）
  const history = active ? active.history : {};
  const members = active ? active.members : [];
  const invite = active ? active.invite : null;
  const hasHousehold = !!active;

  // apply fn(household)->household to the active household only
  const mutateActive = (fn) => setHouseholds(hs => hs.map(h => h.id === activeId ? fn(h) : h));

  // ── households: create / switch / leave ──
  const createHousehold = (name, opts = {}) => {
    const id = newHHId();
    const hh = buildHousehold(id, { name, ...opts });
    setHouseholds(hs => [...hs, hh]);
    setActiveId(id);
    return id;
  };
  const switchHousehold = (id) => { if (households.some(h => h.id === id)) setActiveId(id); };
  const renameHousehold = (id, name) => {
    const nm = (name || '').trim();
    if (!nm) return;
    setHouseholds(hs => hs.map(h => h.id === id ? { ...h, name: nm } : h));
    flash('世帯名を変更しました', 'replenish');
  };
  const leaveHousehold = (id) => {
    const rest = households.filter(h => h.id !== id);
    setHouseholds(rest);
    if (activeId === id) setActiveId(rest.length ? rest[0].id : null);
    flash('世帯から退出しました', 'consume');
  };
  const resetAll = () => { setHouseholds([]); setActiveId(null); };

  // invited user joins an existing household — perspective: inviter is owner, you are a member
  const joinHousehold = (myName, inviter, role, householdName) => {
    return createHousehold(householdName, { seedProducts: true, asMember: true, inviter, myName, myRole: role });
  };

  // ── invites & members (operate on the active household) ──
  const createInvite = (role) => {
    const now = Date.now();
    const inv = { id: 'inv' + now, code: genCode(), role: role || 'member', createdAt: now, expiresAt: now + 7 * 86400000 };
    mutateActive(h => ({ ...h, invite: inv }));
    return inv;
  };
  const setInviteRole = (role) => mutateActive(h => h.invite ? { ...h, invite: { ...h.invite, role } } : h);
  const revokeInvite = () => mutateActive(h => ({ ...h, invite: null }));
  const changeRole = (uid, role) => { mutateActive(h => ({ ...h, members: h.members.map(m => m.id === uid ? { ...m, role } : m) })); flash('権限を変更しました', 'replenish'); };
  const removeMember = (uid) => { mutateActive(h => ({ ...h, members: h.members.filter(m => m.id !== uid) })); flash('メンバーを世帯から外しました', 'consume'); };
  // demo: simulate someone joining via the active link
  const acceptInvite = (name) => {
    if (!invite) return;
    const palette = ['oklch(0.6 0.12 152)', 'oklch(0.62 0.13 330)', 'oklch(0.6 0.12 60)'];
    const nm = name || 'けんた';
    mutateActive(h => ({
      ...h,
      members: [...h.members, { id: 'u' + Date.now(), name: nm, initial: nm[0], color: palette[h.members.length % palette.length], role: h.invite ? h.invite.role : 'member', joinedAt: Date.now() }],
      invite: null,
    }));
    flash(`${nm} さんが世帯に参加しました`, 'replenish');
  };

  // ── inventory (operate on the active household) ──
  const replenish = (pid, qty, occurredAt, note) => {
    const p = products.find(x => x.id === pid);
    mutateActive(h => ({
      ...h,
      products: h.products.map(x => x.id === pid ? { ...x, qty: x.qty + qty, wanted: false } : x),
      history: { ...h.history, [pid]: [{ id: 'h' + Date.now(), kind: 'replenish', qty, occurredAt, by: 'me', note: note || '', corrected: false }, ...(h.history[pid] || [])] },
    }));
    flash(`${p?.name || '商品'} を ${qty}${p?.unit || ''} 補充しました`, 'replenish');
  };
  const consume = (pid, qty, occurredAt, note) => {
    const p = products.find(x => x.id === pid);
    mutateActive(h => ({
      ...h,
      products: h.products.map(x => x.id === pid ? { ...x, qty: x.qty - qty } : x),
      history: { ...h.history, [pid]: [{ id: 'h' + Date.now(), kind: 'consume', qty, occurredAt, by: 'me', note: note || '', corrected: false }, ...(h.history[pid] || [])] },
    }));
    flash(`${p?.name || '商品'} を ${qty}${p?.unit || ''} 消費しました`, 'consume');
  };
  const adopt = (item, opts = {}) => {
    const o = typeof opts === 'number' ? { min: opts } : opts;
    // 同名のアーカイブ済み商品があれば、複製せず復元する（設定・履歴を引き継ぐ）
    const arch = allProducts.find(p => p.name === item.name && p.archived);
    if (arch) {
      mutateActive(h => ({ ...h, products: h.products.map(x => x.id === arch.id ? { ...x, archived: false, unit: o.unit || x.unit, min: o.min ?? x.min } : x) }));
      flash(`${item.name} を在庫に戻しました`, 'replenish');
      return;
    }
    const np = { id: 'p' + Date.now(), name: item.name, unit: o.unit || item.unit || '個', cat: item.cat || 'misc',
      qty: 0, min: o.min ?? 1, daily: item.daily ?? 0.05, icon: item.icon || 'box', image: o.image || item.image || null,
      jan: item.jan || null, custom: !!item.custom };
    mutateActive(h => ({ ...h, products: [np, ...h.products], history: { ...h.history, [np.id]: [] } }));
    flash(`${item.name} を世帯の在庫に追加しました`, 'replenish');
  };
  const setMin = (pid, min) => mutateActive(h => ({ ...h, products: h.products.map(p => p.id === pid ? { ...p, min } : p) }));
  // 手動で買い物リストに入れる／外す（在庫が十分でも自分の意思で買いたい時）
  const setWanted = (pid, want) => {
    const p = products.find(x => x.id === pid);
    const next = want === undefined ? !(p && p.wanted) : !!want;
    mutateActive(h => ({ ...h, products: h.products.map(x => x.id === pid ? { ...x, wanted: next } : x) }));
    flash(next ? `${p?.name || '商品'} を買い物リストに追加しました` : `${p?.name || '商品'} をリストから外しました`, next ? 'replenish' : 'consume');
  };
  const setUnit = (pid, unit) => { mutateActive(h => ({ ...h, products: h.products.map(p => p.id === pid ? { ...p, unit: unit || p.unit } : p) })); flash('単位を変更しました', 'replenish'); };
  const setImage = (pid, image) => mutateActive(h => ({ ...h, products: h.products.map(p => p.id === pid ? { ...p, image } : p) }));
  // アーカイブ：消さずに非表示にするだけ。設定も履歴もそのまま、いつでも在庫に戻せる。
  const archive = (pid) => {
    const p = allProducts.find(x => x.id === pid);
    mutateActive(h => ({ ...h, products: h.products.map(x => x.id === pid ? { ...x, archived: true, wanted: false } : x) }));
    flash(`${p?.name || '商品'} をアーカイブしました`, 'consume');
  };
  const unarchive = (pid) => {
    const p = allProducts.find(x => x.id === pid);
    mutateActive(h => ({ ...h, products: h.products.map(x => x.id === pid ? { ...x, archived: false } : x) }));
    flash(`${p?.name || '商品'} を在庫に戻しました`, 'replenish');
  };
  const correct = (pid, hid, qty, reason) => {
    mutateActive(h => ({ ...h, history: { ...h.history, [pid]: (h.history[pid] || []).map(e => e.id === hid ? { ...e, qty, corrected: true, reason } : e) } }));
    flash('数量を訂正しました', 'replenish');
  };

  let flashTimer = React.useRef(null);
  function flash(msg, kind) {
    setToast({ msg, kind, id: Date.now() });
    clearTimeout(flashTimer.current);
    flashTimer.current = setTimeout(() => setToast(null), 2600);
  }

  return {
    products, allProducts, archivedProducts, history, toast, replenish, consume, adopt, setMin, setUnit, setImage, setWanted, archive, unarchive, correct, setToast, flash,
    members, invite, createInvite, setInviteRole, revokeInvite, changeRole, removeMember, acceptInvite,
    households, activeId, active, hasHousehold, createHousehold, switchHousehold, renameHousehold, leaveHousehold, resetAll, joinHousehold,
  };
}

Object.assign(window, {
  SEED, CATALOG, DEMO_SCANS, catalogByJan, onlyDigits, EXTERNAL_DB, lookupJan, USERS, ROLES, ICONS_BY_CAT, statusOf, onShoppingList, predictDays, relTime, fmtDate, genCode, joinLink, useStore, buildHousehold,
});
