// screens-d.jsx — Global activity (履歴), Profile / settings

function ActivityTab({ store, onOpen }) {
  const T = useTheme();
  const { allProducts, history } = store;
  const pById = Object.fromEntries(allProducts.map(p => [p.id, p]));
  const all = [];
  Object.entries(history).forEach(([pid, entries]) => {
    if (!pById[pid]) return;
    entries.forEach(e => all.push({ ...e, pid }));
  });
  all.sort((a, b) => b.occurredAt - a.occurredAt);
  // group by day label
  const groups = {};
  all.forEach(e => {
    const key = relDayLabel(e.occurredAt);
    (groups[key] = groups[key] || []).push(e);
  });
  return (
    <div>
      <div style={{ marginBottom: 18 }}>
        <div style={{ font: `500 13px/1 var(--f)`, color: T.faint }}>世帯のすべての記録</div>
        <div style={{ font: `800 25px/1.1 var(--f)`, color: T.ink, letterSpacing: '-0.02em', marginTop: 7 }}>履歴</div>
      </div>
      {all.length === 0 ? (
        <EmptyState icon="clock" title="まだ記録がありません" sub="補充や消費をすると、ここに事実が積み重なります。" />
      ) : (
        Object.entries(groups).map(([day, entries]) => (
          <div key={day} style={{ marginBottom: 22 }}>
            <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 4px 12px', textTransform: 'none' }}>{day}</div>
            <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, overflow: 'hidden', boxShadow: T.shadow.sm }}>
              {entries.map((e, i) => {
                const p = pById[e.pid]; if (!p) return null;
                const isRep = e.kind === 'replenish';
                const u = USERS[e.by] || USERS.me;
                return (
                  <button key={e.id} onClick={() => onOpen(p)} style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: 13, padding: '13px 15px', cursor: 'pointer',
                    border: 'none', borderTop: i ? `1px solid ${T.lineSoft}` : 'none', background: 'transparent', textAlign: 'left' }}>
                    <div style={{ width: 34, height: 34, borderRadius: 11, flexShrink: 0, display: 'grid', placeItems: 'center',
                      background: isRep ? T.accentSoft : T.surface2, color: isRep ? T.accent : T.sub, border: `1px solid ${T.lineSoft}` }}>
                      <Icon name={isRep ? 'plus' : 'minus'} size={17} stroke={2.2} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ font: `600 14px/1.3 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                      <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginTop: 4 }}>
                        {isRep ? '補充' : '消費'} {e.qty}{p.unit} · {u.name}{e.corrected ? ' · 訂正済' : ''}
                      </div>
                    </div>
                    <div style={{ font: `500 11.5px/1 var(--f)`, color: T.faint, flexShrink: 0 }}>{hm(e.occurredAt)}</div>
                  </button>
                );
              })}
            </div>
          </div>
        ))
      )}
      <div style={{ height: 8 }} />
    </div>
  );
}

function relDayLabel(ts) {
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const diff = Math.floor((d0.getTime() - ts) / 86400000);
  if (ts >= d0.getTime()) return '今日';
  if (diff <= 0) return '昨日';
  if (diff <= 1) return '昨日';
  if (diff < 7) return `${diff + 0}日前`;
  return fmtDate(ts);
}
function hm(ts) { const d = new Date(ts); return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`; }

function Profile({ onLogout, store, onSwitcher, onCreateHousehold, onJoinHousehold, onMaster, onArchived }) {
  const T = useTheme();
  const u = useUser();
  const [name, setName] = React.useState(u.displayName);
  const [editing, setEditing] = React.useState(false);
  const [push, setPush] = React.useState(false);
  const [offline, setOffline] = React.useState(false);
  const [inviteOpen, setInviteOpen] = React.useState(false);
  const [memberSel, setMemberSel] = React.useState(null);
  const [hhEditing, setHhEditing] = React.useState(false);
  const [hhName, setHhName] = React.useState('');

  const hasHH = store.hasHousehold;
  const members = store.members;
  const me = members.find(m => m.you);
  const ownerSelf = me && me.role === 'owner';
  // overlay the live display name onto the "you" member
  const liveMembers = members.map(m => m.you ? { ...m, name, initial: (name || 'あ')[0] } : m);
  const liveSel = memberSel ? liveMembers.find(m => m.id === memberSel.id) || null : null;
  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <div style={{ font: `500 13px/1 var(--f)`, color: T.faint }}>アカウントと世帯</div>
        <div style={{ font: `800 25px/1.1 var(--f)`, color: T.ink, letterSpacing: '-0.02em', marginTop: 7 }}>設定</div>
      </div>

      {/* identity */}
      <div style={{ background: T.surface, borderRadius: T.radius.lg, padding: 20, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 15 }}>
          <div style={{ width: 58, height: 58, borderRadius: 99, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', font: `700 24px/1 var(--f)`, flexShrink: 0 }}>{name[0]}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            {editing ? (
              <input autoFocus value={name} onChange={e => setName(e.target.value)} onBlur={() => setEditing(false)}
                onKeyDown={e => e.key === 'Enter' && setEditing(false)}
                style={{ width: '100%', height: 38, borderRadius: 10, border: `1px solid ${T.accent}`, padding: '0 10px', font: `700 17px/1 var(--f)`, color: T.ink, outline: 'none', boxSizing: 'border-box' }} />
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ font: `700 18px/1.2 var(--f)`, color: T.ink }}>{name}</span>
                <button onClick={() => setEditing(true)} style={{ background: 'none', border: 'none', color: T.accent, cursor: 'pointer', display: 'grid', placeItems: 'center' }}><Icon name="pencil" size={15} /></button>
              </div>
            )}
            <div style={{ font: `500 12.5px/1 var(--f)`, color: T.faint, marginTop: 6 }}>Zitadel · you@example.com</div>
          </div>
        </div>
      </div>

      {/* household — sharing & invitations */}
      <SectionLabel>世帯</SectionLabel>
      {!hasHH ? (
        <NoHouseholdCard onCreate={onCreateHousehold} onJoin={onJoinHousehold} />
      ) : (
      <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, overflow: 'hidden', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 14px 12px 18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0, flex: 1 }}>
            <span style={{ width: 32, height: 32, borderRadius: 10, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="home" size={18} /></span>
            <div style={{ minWidth: 0, flex: 1 }}>
              {hhEditing ? (
                <input autoFocus value={hhName} maxLength={50}
                  onChange={e => setHhName(e.target.value)}
                  onBlur={() => { if (hhName.trim()) store.renameHousehold(store.active.id, hhName); setHhEditing(false); }}
                  onKeyDown={e => { if (e.key === 'Enter') { if (hhName.trim()) store.renameHousehold(store.active.id, hhName); setHhEditing(false); } if (e.key === 'Escape') setHhEditing(false); }}
                  style={{ width: '100%', height: 34, borderRadius: 9, border: `1.5px solid ${T.accent}`, padding: '0 10px', font: `700 15px/1 var(--f)`, color: T.ink, outline: 'none', boxSizing: 'border-box', background: T.surface }} />
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, minWidth: 0 }}>
                  <span style={{ font: `700 15.5px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{u.householdName}</span>
                  {ownerSelf && (
                    <button onClick={() => { setHhName(u.householdName); setHhEditing(true); }} style={{ background: 'none', border: 'none', color: T.accent, cursor: 'pointer', display: 'grid', placeItems: 'center', padding: 2, flexShrink: 0 }}>
                      <Icon name="pencil" size={14} />
                    </button>
                  )}
                </div>
              )}
              <div style={{ font: `500 11px/1 var(--f)`, color: T.faint, marginTop: 5 }}>{liveMembers.length}人で共有</div>
            </div>
          </div>
          <button onClick={onSwitcher} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, flexShrink: 0, marginLeft: 8,
            font: `600 12.5px/1 var(--f)`, color: T.accent, background: T.accentSoft, border: 'none', padding: '9px 12px', borderRadius: 99, cursor: 'pointer' }}>
            <Icon name="swap" size={15} />切り替え
          </button>
        </div>

        {/* member rows */}
        <div>
          {liveMembers.map((m) => (
            <button key={m.id} onClick={() => setMemberSel(m)} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '11px 18px', cursor: 'pointer',
              border: 'none', borderTop: `1px solid ${T.lineSoft}`, background: 'transparent', textAlign: 'left' }}>
              <span style={{ width: 38, height: 38, borderRadius: 99, background: m.color, color: '#fff', font: `700 15px/1 var(--f)`, display: 'grid', placeItems: 'center', flexShrink: 0 }}>{m.initial}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <span style={{ font: `600 14.5px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.name}</span>
                  {m.you && <span style={{ font: `600 10px/1 var(--f)`, color: T.sub, background: T.surface2, padding: '3px 6px', borderRadius: 5, flexShrink: 0 }}>あなた</span>}
                </div>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, font: `500 11.5px/1 var(--f)`, color: m.role === 'owner' ? T.accent : T.faint, marginTop: 5 }}>
                  <Icon name={ROLES[m.role].icon} size={12} />{ROLES[m.role].label}
                </div>
              </div>
              <Icon name="chevR" size={16} style={{ color: T.faint, flexShrink: 0 }} />
            </button>
          ))}
        </div>

        {/* invite */}
        <div style={{ padding: 14, borderTop: `1px solid ${T.lineSoft}` }}>
          {ownerSelf ? (
            <React.Fragment>
              <Btn full variant="soft" icon="plus" onClick={() => setInviteOpen(true)}>家族を招待</Btn>
              {store.invite && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 11, padding: '0 2px', font: `500 11.5px/1.4 var(--f)`, color: T.faint }}>
                  <Icon name="link" size={13} style={{ color: T.accent, flexShrink: 0 }} />
                  <span style={{ flex: 1 }}>招待リンクが有効です・コード <b style={{ color: T.sub, fontFamily: 'ui-monospace, monospace', letterSpacing: '0.06em' }}>{store.invite.code}</b></span>
                </div>
              )}
            </React.Fragment>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '2px 2px', font: `500 12px/1.4 var(--f)`, color: T.faint }}>
              <Icon name="crown" size={14} style={{ color: T.faint, flexShrink: 0 }} />
              <span>家族の招待はオーナー（{(members.find(m => m.role === 'owner') || {}).name || ''}）が行えます。</span>
            </div>
          )}
        </div>
      </div>
      )}

      {/* product master — owner only */}
      {hasHH && ownerSelf && (
        <button onClick={onMaster} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 13, padding: '15px 16px', cursor: 'pointer',
          border: `1px solid ${T.lineSoft}`, borderRadius: T.radius.lg, background: T.surface, boxShadow: T.shadow.sm, textAlign: 'left', marginBottom: 16 }}>
          <div style={{ width: 38, height: 38, borderRadius: 11, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="box" size={20} /></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, flexWrap: 'wrap' }}>
              <span style={{ font: `600 14.5px/1.2 var(--f)`, color: T.ink }}>商品マスタを編集</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, font: `600 10px/1 var(--f)`, color: T.accent, background: T.accentSoft, padding: '4px 7px', borderRadius: 6 }}><Icon name="crown" size={11} />オーナー</span>
            </div>
            <div style={{ font: `500 11.5px/1.3 var(--f)`, color: T.faint, marginTop: 5 }}>画像・単位・最低在庫の設定／商品のアーカイブ</div>
          </div>
          <Icon name="chevR" size={17} style={{ color: T.faint, flexShrink: 0 }} />
        </button>
      )}

      {/* preferences */}
      <SectionLabel>環境設定</SectionLabel>
      <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, overflow: 'hidden', marginBottom: 16 }}>
        <ToggleRow icon="bell" label="在庫減少のお知らせ" sub="Web Push で端末に通知" value={push} onChange={setPush} disabled />
        <ToggleRow icon="bolt" label="オフラインで在庫を見る" sub="読み取りのみ・書き込みは要オンライン" value={offline} onChange={setOffline} top disabled />
      </div>

      {hasHH && (
        <React.Fragment>
          <SectionLabel>その他</SectionLabel>
          <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, overflow: 'hidden', marginBottom: 18 }}>
            <LinkRow icon="trend" label="消費の傾向" soon />
            <LinkRow icon="archive" label="アーカイブした商品" top count={store.archivedProducts.length} onClick={onArchived} />
          </div>
        </React.Fragment>
      )}

      <Btn full variant="ghost" onClick={onLogout}>ログアウト</Btn>
      <div style={{ font: `400 11.5px/1.5 var(--f)`, color: T.faint, textAlign: 'center', margin: '14px 0 4px' }}>mindstock · MVP プレビュー</div>
      <div style={{ height: 8 }} />

      <InviteSheet open={inviteOpen} onClose={() => setInviteOpen(false)} store={store} householdName={u.householdName} />
      <MemberSheet open={!!memberSel} member={liveSel} isOwnerSelf={ownerSelf}
        onClose={() => setMemberSel(null)} onChangeRole={store.changeRole} onRemove={store.removeMember} />
    </div>
  );
}

function SectionLabel({ children }) {
  const T = useTheme();
  return <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '4px 4px 10px' }}>{children}</div>;
}

function ToggleRow({ icon, label, sub, value, onChange, top, disabled }) {
  const T = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '15px 16px', borderTop: top ? `1px solid ${T.lineSoft}` : 'none' }}>
      <div style={{ width: 34, height: 34, borderRadius: 10, background: T.surface2, color: disabled ? T.faint : T.sub, display: 'grid', placeItems: 'center', flexShrink: 0, opacity: disabled ? 0.7 : 1 }}><Icon name={icon} size={18} /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ font: `600 14px/1.2 var(--f)`, color: disabled ? T.sub : T.ink }}>{label}</span>
          {disabled && (
            <span style={{ font: `600 10px/1 var(--f)`, color: T.faint, background: T.surface2, border: `1px solid ${T.lineSoft}`,
              padding: '3px 7px', borderRadius: 99, whiteSpace: 'nowrap', flexShrink: 0 }}>将来対応予定</span>
          )}
        </div>
        {sub && <div style={{ font: `500 11.5px/1.3 var(--f)`, color: T.faint, marginTop: 4 }}>{sub}</div>}
      </div>
      <button onClick={disabled ? undefined : () => onChange(!value)} disabled={disabled} style={{
        width: 48, height: 29, borderRadius: 99, border: 'none', cursor: disabled ? 'not-allowed' : 'pointer', position: 'relative',
        background: value ? T.accent : T.line, transition: 'background .2s', flexShrink: 0, opacity: disabled ? 0.45 : 1 }}>
        <span style={{ position: 'absolute', top: 3, left: value ? 22 : 3, width: 23, height: 23, borderRadius: 99, background: '#fff',
          boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'left .2s cubic-bezier(.2,.8,.2,1)' }} />
      </button>
    </div>
  );
}

function LinkRow({ icon, label, top, onClick, count, soon }) {
  const T = useTheme();
  return (
    <button onClick={onClick} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 13, padding: '15px 16px', cursor: onClick ? 'pointer' : 'default',
      border: 'none', borderTop: top ? `1px solid ${T.lineSoft}` : 'none', background: 'transparent', textAlign: 'left' }}>
      <div style={{ width: 34, height: 34, borderRadius: 10, background: T.surface2, color: T.sub, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name={icon} size={18} /></div>
      <div style={{ flex: 1, font: `600 14px/1.2 var(--f)`, color: T.ink }}>{label}</div>
      {count > 0 && <span style={{ font: `600 11.5px/1 var(--f)`, color: T.sub, background: T.surface2, padding: '4px 9px', borderRadius: 99, flexShrink: 0 }}>{count}</span>}
      {soon
        ? <span style={{ font: `600 10px/1 var(--f)`, color: T.faint, background: T.surface2, border: `1px solid ${T.lineSoft}`, padding: '4px 7px', borderRadius: 99, flexShrink: 0 }}>近日</span>
        : <Icon name="chevR" size={17} style={{ color: T.faint }} />}
    </button>
  );
}

Object.assign(window, { ActivityTab, Profile, ToggleRow, LinkRow, SectionLabel });
