// app.jsx — shell: device frames, navigation, toast, tweaks wiring, mounting

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "tone": "clay",
  "device": "mobile",
  "rounded": "soft"
}/*EDITMODE-END*/;

// demo invite an invited user "arrives" with after tapping mindstock.app/join/CODE
const DEMO_INVITE = {
  householdName: 'わたしの家',
  inviter: { name: 'ゆい', initial: 'ゆ', color: 'oklch(0.58 0.12 268)' },
  role: 'member',
  code: 'K7M2PQ',
  members: 2,
};

const NAV = [
  { key: 'stock', label: '在庫', icon: 'home' },
  { key: 'shop', label: '買い物', icon: 'cart' },
  { key: 'add', label: '追加', icon: 'plus', center: true },
  { key: 'activity', label: '履歴', icon: 'clock' },
  { key: 'profile', label: '設定', icon: 'user' },
];

// ── Toast ──
function Toast({ toast }) {
  const T = useTheme();
  if (!toast) return null;
  const isRep = toast.kind === 'replenish';
  return (
    <div key={toast.id} style={{
      position: 'absolute', left: 16, right: 16, bottom: 96, zIndex: 250,
      display: 'flex', alignItems: 'center', gap: 11, padding: '13px 16px', borderRadius: 16,
      background: T.ink, color: T.surface, boxShadow: T.shadow.pop,
      animation: 'toastIn .4s cubic-bezier(.2,1,.3,1)', pointerEvents: 'none',
    }}>
      <span style={{ width: 24, height: 24, borderRadius: 99, background: isRep ? T.accent : 'rgba(255,255,255,0.18)',
        color: '#fff', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
        <Icon name={isRep ? 'check' : 'minus'} size={15} stroke={2.6} />
      </span>
      <span style={{ font: `600 13.5px/1.3 var(--f)` }}>{toast.msg}</span>
    </div>
  );
}

// ── Active screen selector ──
function ScreenSwitch({ tab, store, view, setView, columns, desktop, H }) {
  switch (tab) {
    case 'stock': return <StockHome store={store} view={view} onView={setView} columns={columns} desktop={desktop}
      onReplenish={H.replenish} onConsume={H.consume} onOpen={H.open} onShop={() => H.setTab('shop')} onAdd={() => H.setAdd(true)} onBell={() => H.setNotif(true)} onSwitch={H.openSwitcher} />;
    case 'shop': return <ShoppingList store={store} onReplenish={H.replenish} onOpen={H.open} />;
    case 'activity': return <ActivityTab store={store} onOpen={H.open} />;
    case 'profile': return <Profile onLogout={H.logout} store={store} onSwitcher={H.openSwitcher} onCreateHousehold={H.openCreate} onJoinHousehold={H.openJoin} onMaster={H.openMaster} onArchived={H.openArchived} />;
    default: return null;
  }
}

// ── Mobile bottom nav ──
function BottomNav({ tab, onTab, onAdd }) {
  const T = useTheme();
  return (
    <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 120, padding: '8px 14px calc(14px + env(safe-area-inset-bottom))' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-around', height: 62,
        background: 'color-mix(in oklch, ' + T.surface + ' 82%, transparent)', borderRadius: 22,
        border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.lg, backdropFilter: 'blur(16px) saturate(180%)', WebkitBackdropFilter: 'blur(16px) saturate(180%)' }}>
        {NAV.map(n => n.center ? (
          <button key={n.key} onClick={onAdd} style={{ width: 50, height: 50, borderRadius: 17, border: 'none', cursor: 'pointer',
            background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', boxShadow: T.shadow.md, transform: 'translateY(-2px)' }}>
            <Icon name="plus" size={26} stroke={2.2} />
          </button>
        ) : (
          <button key={n.key} onClick={() => onTab(n.key)} style={{ flex: 1, height: '100%', border: 'none', background: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
            color: tab === n.key ? T.accent : T.faint, transition: 'color .2s' }}>
            <Icon name={n.icon} size={22} stroke={tab === n.key ? 2.1 : 1.7} />
            <span style={{ font: `600 10px/1 var(--f)` }}>{n.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── App content (auth + screens + sheets), chrome-agnostic ──
function AppContent({ device }) {
  const T = useTheme();
  const store = useStore();
  const [phase, setPhase] = React.useState('login'); // login | onboard | join | app
  const [user, setUser] = React.useState({ displayName: 'あなた' });
  const [tab, setTab] = React.useState('stock');
  const [view, setView] = React.useState('list');
  const [move, setMove] = React.useState(null);
  const [addOpen, setAddOpen] = React.useState(false);
  const [settings, setSettings] = React.useState(null);
  const [detail, setDetail] = React.useState(null);
  const [notif, setNotif] = React.useState(false);
  const [switcher, setSwitcher] = React.useState(false);
  const [createHH, setCreateHH] = React.useState(false);
  const [joinHH, setJoinHH] = React.useState(false);
  const [masterOpen, setMasterOpen] = React.useState(false);
  const [archivedOpen, setArchivedOpen] = React.useState(false);

  const H = {
    setTab, setAdd: setAddOpen, setNotif,
    replenish: (p) => setMove({ mode: 'replenish', product: p }),
    consume: (p) => setMove({ mode: 'consume', product: p }),
    open: (p) => setDetail(p),
    openSwitcher: () => setSwitcher(true),
    openCreate: () => setCreateHH(true),
    openJoin: () => setJoinHH(true),
    openMaster: () => setMasterOpen(true),
    openArchived: () => setArchivedOpen(true),
    logout: () => { store.resetAll(); setPhase('login'); setTab('stock'); },
  };
  // keep detail product fresh after mutations
  const liveDetail = detail ? store.products.find(p => p.id === detail.id) || null : null;
  const liveSettings = settings ? store.allProducts.find(p => p.id === settings.id) || null : null;
  const me = store.members.find(m => m.you);
  const isOwner = !!(me && me.role === 'owner');
  const desktop = device === 'desktop';

  if (phase === 'login') {
    return <Login onLogin={() => setPhase('onboard')} onJoin={() => setPhase('join')} />;
  }
  if (phase === 'join') {
    return <JoinFlow invite={DEMO_INVITE}
      onCreateOwn={() => setPhase('onboard')}
      onDecline={() => setPhase('login')}
      onComplete={(nm) => {
        setUser({ displayName: nm || 'あなた' });
        store.joinHousehold(nm, DEMO_INVITE.inviter, DEMO_INVITE.role, DEMO_INVITE.householdName);
        setTab('stock'); setPhase('app');
      }} />;
  }
  if (phase === 'onboard') {
    return <Onboard
      onCancel={() => setPhase('login')}
      onComplete={(name, house) => {
        setUser({ displayName: name || 'あなた' });
        store.createHousehold(house || 'わたしの家', { seedProducts: true, myName: name });
        setTab('stock'); setPhase('app');
      }}
      onSkip={(name) => { setUser({ displayName: name || 'あなた' }); setTab('profile'); setPhase('app'); }} />;
  }

  const hasHH = store.hasHousehold;
  const effTab = hasHH ? tab : 'profile'; // no household → settings only
  const userCtxValue = { displayName: user.displayName, householdName: store.active ? store.active.name : '' };

  const scrollPad = desktop ? '34px 40px 40px' : '54px 18px 96px';
  const noHHScrollPad = desktop ? '34px 40px 40px' : '54px 18px 40px';
  const screenNode = (
    <ScreenSwitch tab={effTab} store={store} view={view} setView={setView} columns={desktop ? 3 : 2} desktop={desktop} H={H} />
  );

  const householdSheets = (
    <React.Fragment>
      <HouseholdSwitcher open={switcher} store={store} onClose={() => setSwitcher(false)}
        onCreate={() => { setSwitcher(false); setCreateHH(true); }}
        onJoin={() => { setSwitcher(false); setJoinHH(true); }} />
      <CreateHouseholdSheet open={createHH} store={store} displayName={user.displayName}
        onClose={() => setCreateHH(false)} onAfter={() => setTab('stock')} />
      <JoinCodeSheet open={joinHH} store={store} displayName={user.displayName}
        onClose={() => setJoinHH(false)} onAfter={() => setTab('stock')} />
    </React.Fragment>
  );

  return (
    <UserCtx.Provider value={userCtxValue}>
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: T.bg }}>
      {desktop ? (
        <DesktopChrome tab={effTab} onTab={setTab} onAdd={() => setAddOpen(true)} onBell={() => setNotif(true)}
          scrollPad={hasHH ? scrollPad : noHHScrollPad} hasHH={hasHH} onSwitcher={() => setSwitcher(true)}>
          {screenNode}
        </DesktopChrome>
      ) : (
        <React.Fragment>
          <div className="scroller" style={{ position: 'absolute', inset: 0, overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
            <div style={{ padding: hasHH ? scrollPad : noHHScrollPad, maxWidth: 520, margin: '0 auto' }}>{screenNode}</div>
          </div>
          {hasHH && <BottomNav tab={effTab} onTab={setTab} onAdd={() => setAddOpen(true)} />}
        </React.Fragment>
      )}

      {/* sheets & overlays */}
      <MoveSheet open={!!move} mode={move?.mode} product={move?.product} onClose={() => setMove(null)}
        onSubmit={(pid, qty, when, note) => (move.mode === 'replenish' ? store.replenish : store.consume)(pid, qty, when, note)} />
      <AddProduct open={addOpen} onClose={() => setAddOpen(false)} onAdopt={store.adopt} existing={store.products} />
      <MasterItemSheet open={!!liveSettings} product={liveSettings} z={230} onClose={() => setSettings(null)}
        onSetUnit={store.setUnit} onSetImage={store.setImage} onSetMin={store.setMin}
        onArchive={(id) => { store.archive(id); setSettings(null); setDetail(null); }} />
      <ProductDetail open={!!liveDetail} product={liveDetail} history={store.history} onClose={() => setDetail(null)} canEdit={isOwner}
        onReplenish={H.replenish} onConsume={H.consume} onSettings={(p) => setSettings(p)} onCorrect={store.correct} onToggleWanted={store.setWanted} />
      <NotifSheet open={notif} products={store.products} onClose={() => setNotif(false)} onOpen={H.open} />
      {householdSheets}
      <MasterScreen open={masterOpen} store={store} onClose={() => setMasterOpen(false)} onAdd={() => setAddOpen(true)} />
      <ArchivedScreen open={archivedOpen} store={store} canRestore={isOwner} onClose={() => setArchivedOpen(false)} />
      <Toast toast={store.toast} />
    </div>
    </UserCtx.Provider>
  );
}

// ── Desktop chrome: sidebar + content ──
function DesktopChrome({ tab, onTab, onAdd, onBell, scrollPad, hasHH, onSwitcher, children }) {
  const T = useTheme();
  const u = useUser();
  const items = NAV.filter(n => !n.center && (hasHH || n.key === 'profile'));
  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', background: T.bg }}>
      {/* sidebar */}
      <div style={{ width: 248, flexShrink: 0, borderRight: `1px solid ${T.lineSoft}`, background: T.surface,
        display: 'flex', flexDirection: 'column', padding: '24px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '0 8px 18px' }}>
          <div style={{ width: 36, height: 36, borderRadius: 11, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', transform: 'rotate(-6deg)' }}><Icon name="box" size={20} /></div>
          <span style={{ font: `800 18px/1 var(--f)`, color: T.ink, letterSpacing: '-0.02em' }}>mindstock</span>
        </div>

        {/* household switcher */}
        <button onClick={onSwitcher} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 10px', marginBottom: 16, borderRadius: 12,
          border: `1px solid ${T.line}`, background: T.surface2, cursor: 'pointer', textAlign: 'left', width: '100%' }}>
          <span style={{ width: 30, height: 30, borderRadius: 9, background: hasHH ? T.accentSoft : T.surface, color: hasHH ? T.accent : T.faint, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
            <Icon name="home" size={17} />
          </span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: `700 13.5px/1.2 var(--f)`, color: hasHH ? T.ink : T.faint, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{hasHH ? u.householdName : '世帯がありません'}</div>
            <div style={{ font: `500 10.5px/1 var(--f)`, color: T.faint, marginTop: 4 }}>{hasHH ? '切り替え・追加' : 'つくる / 参加する'}</div>
          </div>
          <Icon name="chevD" size={15} style={{ color: T.faint, flexShrink: 0 }} />
        </button>

        {hasHH && <Btn icon="plus" full onClick={onAdd} style={{ marginBottom: 18 }}>商品を追加</Btn>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {items.map(n => {
            const active = tab === n.key;
            return (
              <button key={n.key} onClick={() => onTab(n.key)} style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', borderRadius: 12, cursor: 'pointer',
                border: 'none', background: active ? T.accentSoft : 'transparent', color: active ? T.accent : T.sub,
                font: `600 14.5px/1 var(--f)`, textAlign: 'left', transition: 'all .15s' }}>
                <Icon name={n.icon} size={20} stroke={active ? 2 : 1.7} />{n.label}
              </button>
            );
          })}
        </div>
        <div style={{ flex: 1 }} />
        {hasHH && (
          <button onClick={onBell} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', borderRadius: 12, cursor: 'pointer', border: 'none', background: 'transparent', color: T.sub, font: `600 14.5px/1 var(--f)`, textAlign: 'left' }}>
            <Icon name="bell" size={20} />お知らせ
          </button>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '12px 8px', marginTop: 6, borderTop: `1px solid ${T.lineSoft}` }}>
          <span style={{ width: 34, height: 34, borderRadius: 99, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', font: `700 14px/1 var(--f)` }}>{(u.displayName || 'あ')[0]}</span>
          <div style={{ minWidth: 0 }}>
            <div style={{ font: `600 13.5px/1 var(--f)`, color: T.ink }}>{u.displayName}</div>
            <div style={{ font: `500 11px/1 var(--f)`, color: T.faint, marginTop: 4 }}>{hasHH ? u.householdName : '世帯なし'}</div>
          </div>
        </div>
      </div>
      {/* content */}
      <div className="scroller" style={{ flex: 1, overflowY: 'auto', position: 'relative' }}>
        <div style={{ padding: scrollPad, maxWidth: 880, margin: '0 auto' }}>{children}</div>
      </div>
    </div>
  );
}

// ── Stage: scale device to fit viewport ──
function Stage({ w, h, children }) {
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const fit = () => {
      const pad = window.innerWidth < 700 ? 0 : 48;
      setScale(Math.min(1, (window.innerWidth - pad) / w, (window.innerHeight - pad) / h));
    };
    fit(); window.addEventListener('resize', fit); return () => window.removeEventListener('resize', fit);
  }, [w, h]);
  return (
    <div style={{ width: w * scale, height: h * scale }}>
      <div style={{ width: w, height: h, transform: `scale(${scale})`, transformOrigin: 'top left' }}>{children}</div>
    </div>
  );
}

// ── Root ──
function Root() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const theme = React.useMemo(() => {
    const base = makeTheme(t.tone);
    if (t.rounded === 'sharp') return { ...base, radius: { sm: 6, md: 8, lg: 11, xl: 14 } };
    if (t.rounded === 'round') return { ...base, radius: { sm: 16, md: 22, lg: 28, xl: 36 } };
    return base;
  }, [t.tone, t.rounded]);
  const desktop = t.device === 'desktop';

  return (
    <ThemeCtx.Provider value={theme}>
      <div style={{ minHeight: '100vh', width: '100%', display: 'grid', placeItems: 'center', background: theme.bgDeep,
        padding: desktop ? 0 : undefined, transition: 'background .3s' }}>
        {desktop ? (
          <Stage w={1180} h={760}>
            <div style={{ width: '100%', height: '100%', borderRadius: 18, overflow: 'hidden', position: 'relative',
              boxShadow: '0 40px 90px rgba(0,0,0,0.22), 0 0 0 1px rgba(0,0,0,0.06)', background: theme.surface }}>
              <div style={{ height: 38, background: theme.surface, borderBottom: `1px solid ${theme.lineSoft}`, display: 'flex', alignItems: 'center', padding: '0 16px', gap: 8 }}>
                {['#ff5f57', '#febc2e', '#28c840'].map(c => <span key={c} style={{ width: 12, height: 12, borderRadius: 99, background: c }} />)}
                <span style={{ font: `500 12.5px/1 var(--f)`, color: theme.faint, margin: '0 auto' }}>mindstock.app</span>
              </div>
              <div style={{ position: 'absolute', top: 38, left: 0, right: 0, bottom: 0 }}>
                <AppContent device="desktop" />
              </div>
            </div>
          </Stage>
        ) : (
          <Stage w={402} h={874}>
            <IOSDevice>
              <div style={{ position: 'absolute', inset: 0 }}>
                <AppContent device="mobile" />
              </div>
            </IOSDevice>
          </Stage>
        )}
      </div>

      <TweaksPanel>
        <TweakSection label="ビジュアル" />
        <TweakRadio label="トーン" value={t.tone} options={[
          { value: 'clay', label: 'Clay' }, { value: 'indigo', label: 'Indigo' }, { value: 'pine', label: 'Pine' }]}
          onChange={(v) => setTweak('tone', v)} />
        <TweakRadio label="角丸" value={t.rounded} options={[
          { value: 'sharp', label: 'シャープ' }, { value: 'soft', label: 'ソフト' }, { value: 'round', label: '丸め' }]}
          onChange={(v) => setTweak('rounded', v)} />
        <TweakSection label="プレビュー" />
        <TweakRadio label="デバイス" value={t.device} options={[
          { value: 'mobile', label: 'モバイル' }, { value: 'desktop', label: 'デスクトップ' }]}
          onChange={(v) => setTweak('device', v)} />
      </TweaksPanel>
    </ThemeCtx.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root />);
