// screens-join.jsx — what an invited user sees after tapping mindstock.app/join/CODE
// Branches off the normal onboarding: you JOIN an existing household (no "create" step).

function JoinFlow({ invite, onComplete, onCreateOwn, onDecline }) {
  const T = useTheme();
  const [step, setStep] = React.useState(0); // 0 landing, 1 name, 2 confirm
  const [name, setName] = React.useState('');
  const [busy, setBusy] = React.useState(false);     // "logging in"
  const [joining, setJoining] = React.useState(false); // "joining"
  const role = ROLES[invite.role] || ROLES.member;

  const login = () => { setBusy(true); setTimeout(() => { setBusy(false); setStep(1); }, 750); };
  const finish = () => { setJoining(true); setTimeout(() => onComplete(name.trim()), 850); };

  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', background: `linear-gradient(180deg, ${T.bg}, ${T.bgDeep})` }}>
      {/* top bar */}
      <div style={{ padding: '52px 24px 6px', display: 'flex', alignItems: 'center', gap: 14, minHeight: 56 }}>
        {step === 1 && (
          <button onClick={() => setStep(0)} style={{ width: 38, height: 38, borderRadius: 12, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer', flexShrink: 0 }}>
            <Icon name="chevL" size={19} />
          </button>
        )}
        {step >= 1 && (
          <React.Fragment>
            <div style={{ display: 'flex', gap: 7, flex: 1, alignItems: 'center' }}>
              {[0, 1].map(i => <div key={i} style={{ flex: 1, height: 5, borderRadius: 99, background: i < step ? T.accent : T.line, transition: 'background .3s' }} />)}
            </div>
            <span style={{ font: `600 12.5px/1 var(--f)`, color: T.faint, flexShrink: 0 }}>{step} / 2</span>
          </React.Fragment>
        )}
      </div>

      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <StepPane key={step}>
          {step === 0 && <JoinLanding T={T} invite={invite} role={role} />}
          {step === 1 && (
            <FormStep T={T} icon="user" eyebrow="プロフィール" title="お名前を教えてください"
              sub={`「${invite.householdName}」のみんなに表示されます。あとから変更できます。`}
              value={name} onChange={setName} placeholder="例: けんた" max={100} active />
          )}
          {step === 2 && <JoinConfirm T={T} invite={invite} role={role} name={name} joining={joining} />}
        </StepPane>
      </div>

      {/* footer */}
      <div style={{ padding: '14px 24px calc(26px + env(safe-area-inset-bottom))' }}>
        {step === 0 && (
          <React.Fragment>
            <Btn full size="lg" icon={busy ? undefined : 'box'} disabled={busy} onClick={login}>{busy ? 'Zitadel に接続中…' : 'ログインして参加'}</Btn>
            <button onClick={onCreateOwn} style={{ width: '100%', marginTop: 12, background: 'none', border: 'none', color: T.faint, font: `500 13px/1 var(--f)`, cursor: 'pointer' }}>自分の世帯をつくる</button>
          </React.Fragment>
        )}
        {step === 1 && (
          <Btn full size="lg" disabled={!name.trim()} onClick={() => setStep(2)}>確認する</Btn>
        )}
        {step === 2 && (
          <React.Fragment>
            <Btn full size="lg" disabled={joining} onClick={finish}>{joining ? '参加中…' : `${invite.householdName} に参加する`}</Btn>
            <button onClick={() => setStep(1)} disabled={joining} style={{ width: '100%', marginTop: 12, background: 'none', border: 'none', color: T.faint, font: `500 13px/1 var(--f)`, cursor: joining ? 'default' : 'pointer' }}>修正する</button>
          </React.Fragment>
        )}
      </div>
    </div>
  );
}

// the link-tap landing — who invited you, to which household, with what role
function JoinLanding({ T, invite, role }) {
  const others = invite.members || 2;
  return (
    <div style={{ padding: '6px 28px 24px', display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* brand row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: 11, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', transform: 'rotate(-6deg)' }}><Icon name="box" size={19} stroke={1.8} /></div>
        <span style={{ font: `800 16px/1 var(--f)`, color: T.ink, letterSpacing: '-0.02em' }}>mindstock</span>
      </div>

      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, font: `600 12.5px/1 var(--f)`, color: T.accent, marginBottom: 12 }}>
          <Icon name="link" size={15} />招待リンク
        </div>
        <div style={{ font: `800 23px/1.4 var(--f)`, color: T.ink, letterSpacing: '-0.01em' }}>
          <span style={{ color: T.accent }}>{invite.inviter.name}</span> さんが<br />「{invite.householdName}」に招待しています
        </div>
      </div>

      {/* household preview card */}
      <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, padding: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
          <span style={{ width: 48, height: 48, borderRadius: 14, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="home" size={24} /></span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: `700 16px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{invite.householdName}</div>
            <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginTop: 5 }}>すでに {others} 人が在庫を共有中</div>
          </div>
        </div>
        {/* member avatars + you */}
        <div style={{ display: 'flex', alignItems: 'center', marginTop: 16 }}>
          {[invite.inviter, { initial: '＋', color: T.surface2 }].slice(0, others - 1 < 0 ? 1 : 99).map((m, i) => (
            <span key={i} style={{ width: 34, height: 34, borderRadius: 99, background: i === 0 ? m.color : T.surface2, color: i === 0 ? '#fff' : T.faint,
              font: `700 13px/1 var(--f)`, display: 'grid', placeItems: 'center', border: `2px solid ${T.surface}`, marginLeft: i ? -9 : 0 }}>{m.initial}</span>
          ))}
          <span style={{ width: 34, height: 34, borderRadius: 99, background: T.accent, color: T.onAccent, font: `700 12px/1 var(--f)`,
            display: 'grid', placeItems: 'center', border: `2px solid ${T.surface}`, marginLeft: -9 }}>あなた</span>
          <span style={{ font: `500 12px/1.3 var(--f)`, color: T.faint, marginLeft: 12 }}>あなたが新しく加わります</span>
        </div>
      </div>

      {/* role you'll get */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 16px', borderRadius: T.radius.md, background: T.surface, border: `1px solid ${T.lineSoft}` }}>
        <span style={{ width: 36, height: 36, borderRadius: 11, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name={role.icon} size={18} /></span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: `600 13.5px/1.2 var(--f)`, color: T.ink }}>権限：{role.label}</div>
          <div style={{ font: `500 11.5px/1.4 var(--f)`, color: T.faint, marginTop: 4 }}>{role.desc}</div>
        </div>
      </div>
    </div>
  );
}

function JoinConfirm({ T, invite, role, name, joining }) {
  return (
    <div style={{ padding: '20px 28px', display: 'flex', flexDirection: 'column', gap: 22, justifyContent: 'center', height: '100%' }}>
      <div>
        <div style={{ font: `600 12.5px/1 var(--f)`, color: T.accent, marginBottom: 9 }}>最終確認</div>
        <div style={{ font: `800 22px/1.3 var(--f)`, color: T.ink }}>この世帯に参加します</div>
      </div>
      <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 18 }}>
          <span style={{ width: 48, height: 48, borderRadius: 99, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', font: `700 20px/1 var(--f)`, flexShrink: 0 }}>{(name || 'あ')[0]}</span>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginBottom: 5 }}>あなた · {role.label}</div>
            <div style={{ font: `700 16px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name || '—'}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 18, borderTop: `1px solid ${T.lineSoft}` }}>
          <span style={{ width: 48, height: 48, borderRadius: 14, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="home" size={24} /></span>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginBottom: 5 }}>参加する世帯（{invite.inviter.name} さんの世帯）</div>
            <div style={{ font: `700 16px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{invite.householdName}</div>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, font: `500 12.5px/1.5 var(--f)`, color: T.faint }}>
        <Icon name="check" size={16} style={{ color: T.status.ok.color, flexShrink: 0 }} />
        <span>参加すると、この世帯の在庫をすぐに一緒に管理できます。権限はオーナーが変更できます。</span>
      </div>
    </div>
  );
}

Object.assign(window, { JoinFlow });
