// screens-b.jsx — Replenish / Consume sheets, Add product, Product settings

function DatePick({ value, onChange }) {
  const T = useTheme();
  const now = Date.now(), D = 86400000;
  const opts = [{ label: '今日', v: now }, { label: '昨日', v: now - D }, { label: 'おととい', v: now - 2 * D }];
  return (
    <div>
      <div style={{ font: `600 12.5px/1 var(--f)`, color: T.faint, marginBottom: 9 }}>いつの出来事？</div>
      <div style={{ display: 'flex', gap: 8 }}>
        {opts.map(o => {
          const active = Math.abs(value - o.v) < D / 2;
          return (
            <button key={o.label} onClick={() => onChange(o.v)} style={{
              flex: 1, height: 42, borderRadius: 12, cursor: 'pointer', font: `600 13.5px/1 var(--f)`,
              border: `1px solid ${active ? T.accent : T.line}`, background: active ? T.accentSoft : T.surface,
              color: active ? T.accent : T.sub, transition: 'all .15s',
            }}>{o.label}</button>
          );
        })}
        <button style={{ width: 46, height: 42, borderRadius: 12, border: `1px solid ${T.line}`, background: T.surface, color: T.sub, display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
          <Icon name="cal" size={19} />
        </button>
      </div>
    </div>
  );
}

function MoveSheet({ open, mode, product, onClose, onSubmit }) {
  const T = useTheme();
  const [qty, setQty] = React.useState(1);
  const [when, setWhen] = React.useState(Date.now());
  const [note, setNote] = React.useState('');
  React.useEffect(() => { if (open) { setQty(1); setWhen(Date.now()); setNote(''); } }, [open, product]);
  if (!product) return null;
  const isRep = mode === 'replenish';
  const after = isRep ? product.qty + qty : product.qty - qty;
  return (
    <Sheet open={open} onClose={onClose} title={isRep ? '補充する' : '消費する'} z={230}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '14px 16px', borderRadius: T.radius.md,
        background: T.surface2, marginBottom: 22 }}>
        <Thumb icon={product.icon} image={product.image} size={42} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: `600 15px/1.3 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{product.name}</div>
          <div style={{ font: `500 12.5px/1 var(--f)`, color: T.faint, marginTop: 5 }}>現在 {product.qty}{product.unit}</div>
        </div>
      </div>

      <div style={{ marginBottom: 22 }}>
        <Stepper value={qty} onChange={setQty} unit={product.unit} />
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, marginBottom: 22,
        font: `500 13.5px/1 var(--f)`, color: T.sub }}>
        <span>{product.qty}{product.unit}</span>
        <Icon name="chevR" size={15} style={{ color: T.faint }} />
        <span style={{ font: `700 16px/1 var(--f)`, color: after < 0 ? T.status.out.color : T.ink }}>{after}{product.unit}</span>
        {after < 0 && <span style={{ font: `600 11.5px/1 var(--f)`, color: T.status.out.color }}>マイナス在庫</span>}
      </div>

      <div style={{ marginBottom: 20 }}>
        <DatePick value={when} onChange={setWhen} />
      </div>

      <input value={note} onChange={e => setNote(e.target.value)} placeholder="メモ（任意・まとめ買い 等）"
        style={{ width: '100%', height: 46, borderRadius: 12, border: `1px solid ${T.line}`, background: T.surface,
          padding: '0 14px', font: `400 14px/1 var(--f)`, color: T.ink, marginBottom: 18, boxSizing: 'border-box', outline: 'none' }} />

      <Btn full size="lg" variant={isRep ? 'primary' : 'primary'}
        onClick={() => { onSubmit(product.id, qty, when, note); onClose(); }}>
        {isRep ? `${qty}${product.unit} 補充する` : `${qty}${product.unit} 消費する`}
      </Btn>
    </Sheet>
  );
}

// ── Barcode / JAN camera scanner (prototype mock of a live camera) ──
function BarcodeScanner({ open, onClose, existing = [], onAdopt, onAddNew, captureOnly, onCapture }) {
  const T = useTheme();
  const [phase, setPhase] = React.useState('scan'); // scan | result | manual
  const [detected, setDetected] = React.useState(null);
  const [torch, setTorch] = React.useState(false);
  const [manual, setManual] = React.useState('');
  const [newName, setNewName] = React.useState('');
  const [lookupState, setLookupState] = React.useState('idle'); // idle | loading | done
  const [fetched, setFetched] = React.useState(null);           // 外部APIヒット結果 or null
  const idx = React.useRef(0);

  React.useEffect(() => {
    if (open) { setPhase('scan'); setDetected(null); setTorch(false); setManual(''); setNewName(''); setLookupState('idle'); setFetched(null); }
  }, [open]);

  // JANが自社マスタに無いとき、バックエンド経由でAPI照会する想定の擬似ルックアップ
  React.useEffect(() => {
    if (phase !== 'result' || captureOnly || !detected) return;
    if (catalogByJan(detected)) return; // 自社マスタにある → 照会不要
    setLookupState('loading'); setFetched(null);
    const t = setTimeout(() => {
      const ext = lookupJan(detected);
      setFetched(ext); setNewName(ext ? ext.name : ''); setLookupState('done');
    }, 1200);
    return () => clearTimeout(t);
  }, [phase, detected, captureOnly]);

  // auto-detect after a beat while actively scanning (feels like a real read)
  React.useEffect(() => {
    if (!open || phase !== 'scan') return;
    const t = setTimeout(() => fire(DEMO_SCANS[idx.current % DEMO_SCANS.length]), 2300);
    return () => clearTimeout(t);
  }, [open, phase]);

  if (!open) return null;

  const fire = (jan) => { idx.current += 1; if (captureOnly) { onCapture && onCapture(jan); return; } setDetected(jan); setPhase('result'); };
  const item = detected ? catalogByJan(detected) : null;
  const adopted = item ? existing.some(e => e.name === item.name) : false;
  const dupByJan = detected ? existing.some(e => e.jan && e.jan === detected) : false;

  const rescan = () => { setDetected(null); setNewName(''); setLookupState('idle'); setFetched(null); setPhase('scan'); };

  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 240, background: '#13110f', overflow: 'hidden',
      display: 'flex', flexDirection: 'column' }}>
      {/* simulated camera feed */}
      <div style={{ position: 'absolute', inset: 0,
        background: `radial-gradient(120% 90% at 50% 38%, #2a2724 0%, #1a1714 55%, #0d0b0a 100%)` }} />
      <div style={{ position: 'absolute', inset: 0, opacity: torch ? 0.22 : 0.1, transition: 'opacity .3s',
        background: `repeating-linear-gradient(58deg, transparent, transparent 13px, rgba(255,255,255,0.5) 13px, rgba(255,255,255,0.5) 14px)` }} />
      <div style={{ position: 'absolute', top: 'calc(50% - 150px)', left: 0, right: 0, textAlign: 'center',
        font: `500 10.5px/1 ui-monospace, SFMono-Regular, Menlo, monospace`, color: 'rgba(255,255,255,0.32)', letterSpacing: '0.14em' }}>
        CAMERA FEED · DEMO
      </div>

      {/* top bar */}
      <div style={{ position: 'relative', zIndex: 3, padding: '16px 18px 0', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={onClose} style={scanGlassBtn}><Icon name="x" size={20} /></button>
        <div style={{ flex: 1, textAlign: 'center', font: `700 15.5px/1 var(--f)`, color: '#fff' }}>{captureOnly ? 'バーコードを読み取る' : 'バーコードをスキャン'}</div>
        <button onClick={() => setTorch(t => !t)} style={{ ...scanGlassBtn,
          background: torch ? 'rgba(255,255,255,0.92)' : 'rgba(255,255,255,0.12)', color: torch ? '#1a1714' : '#fff' }}>
          <Icon name="bolt" size={19} />
        </button>
      </div>

      {/* viewfinder */}
      <div style={{ position: 'relative', zIndex: 2, flex: 1, display: 'grid', placeItems: 'center', padding: '0 36px' }}>
        <div onClick={phase === 'scan' ? () => fire(DEMO_SCANS[idx.current % DEMO_SCANS.length]) : undefined}
          style={{ position: 'relative', width: '100%', maxWidth: 300, aspectRatio: '1 / 0.74', borderRadius: 22,
            boxShadow: '0 0 0 100vmax rgba(8,6,5,0.62)', cursor: phase === 'scan' ? 'pointer' : 'default' }}>
          {/* corner brackets */}
          {[['top:-2px;left:-2px', 'border-top;border-left', '22px 0 0 0'],
            ['top:-2px;right:-2px', 'border-top;border-right', '0 22px 0 0'],
            ['bottom:-2px;left:-2px', 'border-bottom;border-left', '0 0 0 22px'],
            ['bottom:-2px;right:-2px', 'border-bottom;border-right', '0 0 22px 0']].map((c, i) => {
            const pos = Object.fromEntries(c[0].split(';').map(s => s.split(':')));
            const bd = c[1].split(';').reduce((o, k) => (o[k] = `3px solid ${phase === 'scan' ? '#fff' : T.accentHi}`, o), {});
            return <span key={i} style={{ position: 'absolute', width: 30, height: 30, borderRadius: c[2], transition: 'border-color .3s', ...pos, ...bd }} />;
          })}
          {/* scan line */}
          {phase === 'scan' && (
            <span style={{ position: 'absolute', left: 10, right: 10, height: 2, borderRadius: 2,
              background: `linear-gradient(90deg, transparent, ${T.accentHi}, transparent)`,
              boxShadow: `0 0 14px 2px ${T.accentHi}`, animation: 'scanSweep 2.3s cubic-bezier(.45,.05,.55,.95) infinite' }} />
          )}
          {/* detection flash */}
          {detected && <span key={detected} style={{ position: 'absolute', inset: 0, borderRadius: 22, background: '#fff', animation: 'scanFlash .5s ease-out' }} />}
        </div>
      </div>

      {/* bottom guidance / manual entry */}
      <div style={{ position: 'relative', zIndex: 3, padding: '0 22px calc(26px + env(safe-area-inset-bottom))', textAlign: 'center' }}>
        {phase !== 'manual' && (
          <React.Fragment>
            <div style={{ font: `600 13.5px/1.5 var(--f)`, color: 'rgba(255,255,255,0.86)', marginBottom: 4 }}>
              商品のバーコードを枠内に合わせてください
            </div>
            <div style={{ font: `500 11.5px/1 var(--f)`, color: 'rgba(255,255,255,0.4)', marginBottom: 18 }}>
              JANコードを自動で読み取ります（枠をタップでも可）
            </div>
            <button onClick={() => setPhase('manual')} style={{ ...scanGlassBtn, width: 'auto', height: 44, padding: '0 18px', gap: 9,
              borderRadius: 13, margin: '0 auto', font: `600 13.5px/1 var(--f)` }}>
              <Icon name="keyboard" size={18} />番号を手で入力
            </button>
          </React.Fragment>
        )}
      </div>

      {/* manual JAN entry sheet */}
      {phase === 'manual' && (
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 5, background: T.surface,
          borderRadius: '24px 24px 0 0', padding: '12px 22px calc(24px + env(safe-area-inset-bottom))',
          boxShadow: T.shadow.pop, animation: 'sheetUp .42s cubic-bezier(.2,.9,.25,1)' }}>
          <div style={{ width: 40, height: 5, borderRadius: 99, background: T.line, margin: '0 auto 16px' }} />
          <div style={{ font: `700 17px/1.2 var(--f)`, color: T.ink, marginBottom: 4 }}>JANコードを入力</div>
          <div style={{ font: `500 12px/1.4 var(--f)`, color: T.faint, marginBottom: 16 }}>パッケージのバーコード下にある13桁の数字です。</div>
          <input autoFocus inputMode="numeric" value={manual}
            onChange={e => setManual(onlyDigits(e.target.value).slice(0, 13))}
            placeholder="例: 4901750901234"
            style={{ width: '100%', height: 52, borderRadius: 14, border: `1px solid ${T.line}`, background: T.surface,
              padding: '0 16px', font: `600 17px/1 ui-monospace, Menlo, monospace`, letterSpacing: '0.06em',
              color: T.ink, boxSizing: 'border-box', outline: 'none', marginBottom: 16 }} />
          <div style={{ display: 'flex', gap: 10 }}>
            <Btn variant="ghost" onClick={rescan} style={{ flex: 1 }}>戻る</Btn>
            <Btn disabled={manual.length < 8} onClick={() => fire(manual)} style={{ flex: 2 }}>このコードで検索</Btn>
          </div>
        </div>
      )}

      {/* result card */}
      {phase === 'result' && (
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 5, background: T.surface,
          borderRadius: '24px 24px 0 0', padding: '12px 22px calc(24px + env(safe-area-inset-bottom))',
          boxShadow: T.shadow.pop, animation: 'sheetUp .42s cubic-bezier(.2,.9,.25,1)' }}>
          <div style={{ width: 40, height: 5, borderRadius: 99, background: T.line, margin: '0 auto 16px' }} />

          {dupByJan ? (
            <React.Fragment>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, font: `700 12.5px/1 var(--f)`, color: T.sub, marginBottom: 14 }}>
                <Icon name="check" size={16} stroke={2.6} />読み取り完了
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, borderRadius: T.radius.lg, background: T.surface2, marginBottom: 16 }}>
                <span style={{ width: 52, height: 52, borderRadius: 14, background: T.surface, border: `1px solid ${T.lineSoft}`, color: T.sub, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="check" size={24} stroke={2.4} /></span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `700 15px/1.3 var(--f)`, color: T.ink }}>すでに世帯に登録されています</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 7 }}>
                    <Icon name="barcode" size={14} style={{ color: T.faint }} />
                    <span style={{ font: `600 12px/1 ui-monospace, Menlo, monospace`, letterSpacing: '0.05em', color: T.sub }}>{detected}</span>
                  </div>
                </div>
              </div>
              <div style={{ font: `500 12.5px/1.5 var(--f)`, color: T.faint, textAlign: 'center', marginBottom: 14 }}>このJANコードの商品はすでに在庫にあります。</div>
              <div style={{ display: 'flex', gap: 10 }}>
                <Btn variant="ghost" icon="scan" onClick={rescan} style={{ flex: 1 }}>もう一度</Btn>
                <Btn onClick={onClose} style={{ flex: 1 }}>閉じる</Btn>
              </div>
            </React.Fragment>
          ) : item ? (
            <React.Fragment>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, font: `700 12.5px/1 var(--f)`,
                color: adopted ? T.sub : T.status.ok.color, marginBottom: 14 }}>
                <Icon name="check" size={16} stroke={2.6} />読み取り完了
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, borderRadius: T.radius.lg, background: T.surface2, marginBottom: 16 }}>
                <Thumb icon={item.icon} size={52} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `700 15.5px/1.3 var(--f)`, color: T.ink }}>{item.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 7 }}>
                    <Icon name="barcode" size={14} style={{ color: T.faint }} />
                    <span style={{ font: `600 12px/1 ui-monospace, Menlo, monospace`, letterSpacing: '0.05em', color: T.sub }}>{detected}</span>
                  </div>
                </div>
                {adopted && <span style={{ font: `600 11px/1 var(--f)`, color: T.sub, background: T.surface, padding: '6px 9px', borderRadius: 8, flexShrink: 0, whiteSpace: 'nowrap' }}>採用済み</span>}
              </div>
              {adopted ? (
                <React.Fragment>
                  <div style={{ font: `500 12.5px/1.5 var(--f)`, color: T.faint, textAlign: 'center', marginBottom: 14 }}>この商品はすでにこの世帯にあります。</div>
                  <div style={{ display: 'flex', gap: 10 }}>
                    <Btn variant="ghost" icon="scan" onClick={rescan} style={{ flex: 1 }}>もう一度</Btn>
                    <Btn onClick={onClose} style={{ flex: 1 }}>閉じる</Btn>
                  </div>
                </React.Fragment>
              ) : (
                <div style={{ display: 'flex', gap: 10 }}>
                  <Btn variant="ghost" icon="scan" onClick={rescan} style={{ flex: 1 }}>もう一度</Btn>
                  <Btn size="md" onClick={() => onAdopt(item)} style={{ flex: 2 }}>採用にすすむ</Btn>
                </div>
              )}
            </React.Fragment>
          ) : lookupState === 'loading' ? (
            <React.Fragment>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, borderRadius: T.radius.lg, background: T.surface2, marginBottom: 16 }}>
                <span style={{ width: 52, height: 52, borderRadius: 14, background: T.surface, border: `1px solid ${T.lineSoft}`, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                  <span style={{ width: 24, height: 24, borderRadius: 99, border: `2.5px solid ${T.lineSoft}`, borderTopColor: T.accent, animation: 'spin .8s linear infinite' }} />
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `700 15px/1.3 var(--f)`, color: T.ink }}>商品情報を取得中…</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 7 }}>
                    <Icon name="barcode" size={14} style={{ color: T.faint }} />
                    <span style={{ font: `600 12px/1 ui-monospace, Menlo, monospace`, letterSpacing: '0.05em', color: T.sub }}>{detected}</span>
                  </div>
                </div>
              </div>
              <div style={{ font: `500 12px/1.5 var(--f)`, color: T.faint, textAlign: 'center' }}>JANコードから商品名を検索しています…</div>
            </React.Fragment>
          ) : fetched ? (
            <React.Fragment>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, font: `700 12.5px/1 var(--f)`, color: T.status.ok.color, marginBottom: 14 }}>
                <Icon name="check" size={16} stroke={2.6} />商品情報が見つかりました
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, borderRadius: T.radius.lg, background: T.surface2, marginBottom: 14 }}>
                <Thumb icon="box" size={52} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `700 15.5px/1.35 var(--f)`, color: T.ink }}>{fetched.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 7 }}>
                    <Icon name="barcode" size={14} style={{ color: T.faint }} />
                    <span style={{ font: `600 12px/1 ui-monospace, Menlo, monospace`, letterSpacing: '0.05em', color: T.sub }}>{detected}</span>
                  </div>
                </div>
              </div>
              <div style={{ font: `500 11.5px/1.5 var(--f)`, color: T.faint, margin: '0 2px 14px' }}>{fetched.source} の情報から取得しました。この商品名で世帯に追加します。</div>
              <div style={{ display: 'flex', gap: 10 }}>
                <Btn variant="ghost" icon="scan" onClick={rescan} style={{ flex: 1 }}>もう一度</Btn>
                <Btn icon="add" onClick={() => onAddNew({ name: fetched.name, jan: detected, unit: fetched.unit, fromApi: true })} style={{ flex: 2 }}>世帯に追加</Btn>
              </div>
            </React.Fragment>
          ) : (
            <React.Fragment>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, borderRadius: T.radius.lg, background: T.surface2, marginBottom: 16 }}>
                <span style={{ width: 52, height: 52, borderRadius: 14, background: T.surface, border: `1px solid ${T.line}`, color: T.faint, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="search" size={24} /></span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `700 15px/1.3 var(--f)`, color: T.ink }}>商品情報が見つかりません</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 7 }}>
                    <Icon name="barcode" size={14} style={{ color: T.faint }} />
                    <span style={{ font: `600 12px/1 ui-monospace, Menlo, monospace`, letterSpacing: '0.05em', color: T.sub }}>{detected}</span>
                  </div>
                </div>
              </div>
              <div style={{ font: `500 12.5px/1.5 var(--f)`, color: T.faint, marginBottom: 12 }}>データベースにも見つかりませんでした。名前を入れて、その場で世帯の在庫に追加できます（バーコードは紐づきます）。</div>
              <input autoFocus value={newName} onChange={e => setNewName(e.target.value)} placeholder="商品名（例: 麦茶パック）"
                style={{ width: '100%', height: 50, borderRadius: 13, border: `1px solid ${T.line}`, background: T.surface,
                  padding: '0 14px', font: `500 15px/1 var(--f)`, color: T.ink, boxSizing: 'border-box', outline: 'none', marginBottom: 14 }} />
              <div style={{ display: 'flex', gap: 10 }}>
                <Btn variant="ghost" icon="scan" onClick={rescan} style={{ flex: 1 }}>もう一度</Btn>
                <Btn icon="add" disabled={!newName.trim()} onClick={() => onAddNew({ name: newName, jan: detected, fromApi: false })} style={{ flex: 2 }}>世帯に追加</Btn>
              </div>
            </React.Fragment>
          )}
        </div>
      )}
    </div>
  );
}

const scanGlassBtn = { width: 42, height: 42, borderRadius: 13, border: 'none', flexShrink: 0,
  background: 'rgba(255,255,255,0.12)', color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
  cursor: 'pointer', backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)' };

function AddProduct({ open, onClose, onAdopt, existing = [] }) {
  const T = useTheme();
  const [q, setQ] = React.useState('');
  const [picked, setPicked] = React.useState(null);
  const [unit, setUnit] = React.useState('個');
  const [min, setMin] = React.useState(1);
  const [scanMode, setScanMode] = React.useState(null); // null | 'find' | 'attach'
  const [janLoading, setJanLoading] = React.useState(false);
  React.useEffect(() => { if (open) { setQ(''); setPicked(null); setMin(1); setUnit('個'); setScanMode(null); setJanLoading(false); } }, [open]);
  if (!open) return null;
  const has = (name) => existing.some(e => e.name === name);
  // JANは一意 → 同じJANの商品がすでにあれば重複とみなして登録させない（JAN無しは重複チェックしない）
  const hasJan = (jan) => !!jan && existing.some(e => e.jan && e.jan === jan);
  const digits = onlyDigits(q);
  const isJanQuery = digits.length >= 3 && digits.length === q.trim().length;
  const results = CATALOG.filter(c => !q || c.name.includes(q) || (isJanQuery && c.jan && c.jan.includes(digits)));
  const inMaster = CATALOG.some(c => c.name === q.trim() || (c.jan && c.jan === digits));
  // マスタ採用 → 商品名は大元マスタの値で確定（編集不可）
  const pick = (c) => { if (has(c.name) || hasJan(c.jan)) return; setPicked({ ...c, locked: true }); setUnit(c.unit || '個'); setMin(1); };
  // マスタに無い商品は、承認を待たずその場で世帯のカスタム商品として追加する。
  // fromApi=true（JAN照会で外部APIヒット）のときだけ商品名を確定し、それ以外は編集可能。
  const pickCustom = (name, jan, unit, fromApi) => {
    const nm = (name || '').trim();
    if (!nm && fromApi) return;
    if (jan && hasJan(jan)) return; // 同じJANは登録済み → 重複追加しない
    const u = unit || '個';
    setPicked({ id: 'custom', name: nm, unit: u, icon: 'box', jan: jan || null, custom: true, locked: !!fromApi });
    setUnit(u); setMin(1);
  };
  // 検索でJANコードを入力して「世帯に追加」: バックエンド照会（マスタ→外部API）を模した取得フロー
  const runJanAdd = (jan) => {
    if (hasJan(jan)) return;                          // すでに同じJANの商品がある → 登録させない
    const master = catalogByJan(jan);
    if (master) { pick(master); return; }            // 自社マスタにある → そのまま採用
    setJanLoading(true);
    setTimeout(() => {
      const ext = lookupJan(jan);
      if (ext) pickCustom(ext.name, jan, ext.unit, true); // 取得できた → その商品名で確定
      else pickCustom('', jan, null, false);              // 見つからない → 商品名は自分で入力
      setJanLoading(false);
    }, 900);
  };

  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 220, background: T.bg,
      display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 20px 6px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => (picked ? setPicked(null) : onClose())} style={{ width: 40, height: 40, borderRadius: 12, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
          <Icon name="chevL" size={20} />
        </button>
        <div style={{ font: `700 18px/1 var(--f)`, color: T.ink }}>{picked ? (picked.custom ? '世帯に追加する' : '世帯に採用する') : '商品を追加'}</div>
      </div>

      {!picked ? (
        <div className="scroller" style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 24px' }}>
          {/* scan-by-camera entry */}
          <button onClick={() => setScanMode('find')} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 14,
            padding: '15px 16px', borderRadius: T.radius.lg, cursor: 'pointer', textAlign: 'left',
            border: `1px solid ${T.accent}`, background: T.accentSoft, marginBottom: 16, boxShadow: T.shadow.sm }}>
            <span style={{ width: 46, height: 46, borderRadius: 13, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
              <Icon name="barcode" size={24} stroke={2} />
            </span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: `700 15px/1.2 var(--f)`, color: T.ink }}>バーコードでスキャン</div>
              <div style={{ font: `500 12px/1.3 var(--f)`, color: T.sub, marginTop: 4 }}>カメラでJANコードを読み取って探す</div>
            </div>
            <Icon name="camera" size={22} style={{ color: T.accent, flexShrink: 0 }} />
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '0 2px 14px' }}>
            <div style={{ flex: 1, height: 1, background: T.lineSoft }} />
            <span style={{ font: `600 11px/1 var(--f)`, color: T.faint }}>または検索して探す</span>
            <div style={{ flex: 1, height: 1, background: T.lineSoft }} />
          </div>

          <div style={{ position: 'relative', marginBottom: 8 }}>
            <Icon name={isJanQuery ? 'barcode' : 'search'} size={19} style={{ position: 'absolute', left: 14, top: 15, color: isJanQuery ? T.accent : T.faint }} />
            <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="商品名 または JANコードで検索"
              style={{ width: '100%', height: 50, borderRadius: 14, border: `1px solid ${isJanQuery ? T.accent : T.line}`, background: T.surface,
                padding: '0 14px 0 42px', font: `400 15px/1 var(--f)`, color: T.ink, boxSizing: 'border-box', outline: 'none', boxShadow: T.shadow.sm }} />
          </div>
          <div style={{ font: `500 12px/1.5 var(--f)`, color: T.faint, margin: '10px 4px 14px' }}>
            {isJanQuery
              ? `JANコード「${digits}」で商品を検索しています。見つからない場合も、その場で在庫に追加できます。`
              : '商品マスタから選ぶか、見つからない商品はその場で在庫に追加できます。単位や最低在庫はあとから変えられます。'}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {results.map(c => {
              const added = has(c.name) || hasJan(c.jan);
              return (
                <button key={c.id} onClick={() => pick(c)} disabled={added} style={{
                  display: 'flex', alignItems: 'center', gap: 13, padding: 13, borderRadius: T.radius.md, cursor: added ? 'default' : 'pointer',
                  border: `1px solid ${T.lineSoft}`, background: T.surface, boxShadow: T.shadow.sm, textAlign: 'left', opacity: added ? 0.6 : 1, transition: 'all .15s',
                }}>
                  <Thumb icon={c.icon} size={44} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ font: `600 14.5px/1.3 var(--f)`, color: T.ink }}>{c.name}</div>
                    <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginTop: 5 }}>
                      {isJanQuery ? `JAN ${c.jan}` : `標準単位: ${c.unit} · ${c.shared}世帯が利用`}
                    </div>
                  </div>
                  {added ? (
                    <span style={{ font: `600 11px/1 var(--f)`, color: T.sub, background: T.surface2, padding: '6px 9px', borderRadius: 8, flexShrink: 0, whiteSpace: 'nowrap' }}>採用済み</span>
                  ) : (
                    <Icon name="chevR" size={17} style={{ color: T.faint, flexShrink: 0 }} />
                  )}
                </button>
              );
            })}

            {/* マスタに無い → 承認を待たず、その場で世帯の在庫に追加 */}
            {/* マスタに無い → 承認を待たず、その場で世帯の在庫に追加。ただし同じJANは登録済みなら弾く */}
            {q.trim() && !inMaster && !has(q.trim()) && (
              isJanQuery && hasJan(digits) ? (
                <div style={{ marginTop: 4, padding: 16, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, background: T.surface2 }}>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <span style={{ width: 42, height: 42, borderRadius: 12, background: T.surface, color: T.sub, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="check" size={22} stroke={2.4} /></span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ font: `700 14.5px/1.35 var(--f)`, color: T.ink }}>すでに世帯に登録されています</div>
                      <div style={{ font: `400 12px/1.5 var(--f)`, color: T.faint, marginTop: 4 }}>このJANコードの商品はすでに在庫にあります。</div>
                    </div>
                  </div>
                </div>
              ) : (
                <button onClick={() => (isJanQuery ? runJanAdd(digits) : pickCustom(q, null, null, false))} style={{ width: '100%', marginTop: 4, padding: 16, borderRadius: T.radius.lg, border: `1px dashed ${T.accent}`, background: T.surface, cursor: 'pointer', textAlign: 'left' }}>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <span style={{ width: 42, height: 42, borderRadius: 12, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name={isJanQuery ? 'barcode' : 'add'} size={22} /></span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ font: `700 14.5px/1.35 var(--f)`, color: T.ink }}>{isJanQuery ? `JANコード「${digits}」で商品を探す` : `「${q.trim()}」を世帯に追加`}</div>
                      <div style={{ font: `400 12px/1.5 var(--f)`, color: T.faint, marginTop: 4 }}>{isJanQuery ? '商品情報を検索し、見つからなければ名前を入力して追加できます。' : 'マスタに無い商品も、その場で在庫に登録できます。'}</div>
                    </div>
                    <Icon name="chevR" size={18} style={{ color: T.faint, flexShrink: 0 }} />
                  </div>
                </button>
              )
            )}
          </div>
        </div>
      ) : (
        <div className="scroller" style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 16, borderRadius: T.radius.lg, background: T.surface2, marginBottom: 22 }}>
            <Thumb icon={picked.icon} size={52} />
            <div style={{ minWidth: 0 }}>
              <div style={{ font: `700 16px/1.3 var(--f)`, color: T.ink }}>{picked.name || '新しい商品'}</div>
              <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginTop: 5 }}>{picked.custom ? (picked.locked ? 'JANコードから商品情報を取得' : '新しい商品として追加') : '大元のマスタから採用'}</div>
            </div>
          </div>

          {/* 商品名 — マスタ採用 / JAN照会ヒットのときは確定、それ以外は自由に編集できる */}
          <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 2px 10px', display: 'flex', alignItems: 'center', gap: 6 }}>
            商品名
            {!picked.locked && <Icon name="pencil" size={13} style={{ color: T.faint }} />}
          </div>
          {picked.locked ? (
            <div style={{ marginBottom: 24 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', borderRadius: T.radius.md, border: `1px solid ${T.line}`, background: T.surface2 }}>
                <span style={{ flex: 1, font: `600 15px/1.35 var(--f)`, color: T.ink }}>{picked.name}</span>
              </div>
              <div style={{ font: `400 11.5px/1.6 var(--f)`, color: T.faint, marginTop: 9, padding: '0 2px' }}>
                {picked.custom ? 'JANコードから取得した商品名を使用します。' : '商品マスタに登録された商品名です。'}
              </div>
            </div>
          ) : (
            <div style={{ marginBottom: 24 }}>
              <input value={picked.name} onChange={e => setPicked(p => ({ ...p, name: e.target.value }))} placeholder="商品名（例: 麦茶パック）"
                style={{ width: '100%', height: 50, borderRadius: 13, border: `1px solid ${T.line}`, background: T.surface,
                  padding: '0 14px', font: `600 15px/1 var(--f)`, color: T.ink, boxSizing: 'border-box', outline: 'none' }} />
              <div style={{ font: `400 11.5px/1.6 var(--f)`, color: T.faint, marginTop: 9, padding: '0 2px' }}>
                {picked.jan ? 'JANコードでは商品情報が見つかりませんでした。商品名は自由に変更できます。' : '商品名は自由に変更できます。'}
              </div>
            </div>
          )}

          {picked.custom && (
            <div style={{ marginBottom: 24 }}>
              <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 2px 10px' }}>バーコード（任意）</div>
              {picked.jan ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: T.radius.md, border: `1px solid ${T.line}`, background: T.surface }}>
                  <Icon name="barcode" size={20} style={{ color: T.accent, flexShrink: 0 }} />
                  <span style={{ flex: 1, font: `600 14px/1 ui-monospace, Menlo, monospace`, letterSpacing: '0.04em', color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis' }}>{picked.jan}</span>
                  <button onClick={() => setScanMode('find')} style={{ font: `600 12.5px/1 var(--f)`, color: T.accent, background: 'none', border: 'none', cursor: 'pointer', padding: '6px 4px' }}>読み取り直す</button>
                  <button onClick={() => setPicked(p => ({ ...p, jan: null }))} style={{ width: 30, height: 30, borderRadius: 8, border: `1px solid ${T.line}`, background: T.surface, color: T.faint, display: 'grid', placeItems: 'center', cursor: 'pointer', flexShrink: 0 }}><Icon name="x" size={15} stroke={2.2} /></button>
                </div>
              ) : (
                <React.Fragment>
                  <button onClick={() => setScanMode('find')} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', borderRadius: T.radius.md, border: `1px dashed ${T.accent}`, background: T.surface, cursor: 'pointer', textAlign: 'left' }}>
                    <span style={{ width: 36, height: 36, borderRadius: 10, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="barcode" size={20} /></span>
                    <span style={{ flex: 1, font: `600 14px/1.3 var(--f)`, color: T.ink }}>バーコードを読み取って紐づける</span>
                    <Icon name="camera" size={20} style={{ color: T.accent, flexShrink: 0 }} />
                  </button>
                  <div style={{ font: `400 11.5px/1.6 var(--f)`, color: T.faint, marginTop: 9, padding: '0 2px' }}>バーコードがある商品は、読み取っておくと商品情報を自動で補完できます。バーコードが無い商品はそのまま追加できます。</div>
                </React.Fragment>
              )}
            </div>
          )}

          <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 2px 10px' }}>数える単位</div>
          <div style={{ marginBottom: 24 }}><UnitPicker value={unit} onChange={setUnit} /></div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 0', borderTop: `1px solid ${T.lineSoft}`, borderBottom: `1px solid ${T.lineSoft}`, marginBottom: 24 }}>
            <div>
              <div style={{ font: `600 14.5px/1 var(--f)`, color: T.ink }}>最低在庫</div>
              <div style={{ font: `500 12px/1.3 var(--f)`, color: T.faint, marginTop: 5 }}>これ以下で買い物リストへ</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <button onClick={() => setMin(Math.max(0, min - 1))} style={miniStep(T)}><Icon name="minus" size={18} /></button>
              <span style={{ font: `700 22px/1 var(--f)`, color: T.ink, minWidth: 26, textAlign: 'center', fontFeatureSettings: '"tnum"' }}>{min}</span>
              <button onClick={() => setMin(min + 1)} style={miniStep(T)}><Icon name="plus" size={18} /></button>
            </div>
          </div>

          <Btn full size="lg" disabled={!unit.trim() || !picked.name.trim()} onClick={() => { onAdopt({ ...picked, name: picked.name.trim() }, { unit: unit.trim(), min }); onClose(); }}>{picked.custom ? 'この世帯に追加する' : 'この世帯に採用する'}</Btn>
          <div style={{ font: `400 11.5px/1.5 var(--f)`, color: T.faint, textAlign: 'center', marginTop: 12 }}>画像は追加後、商品マスタの編集から設定できます。</div>
        </div>
      )}

      {janLoading && (
        <div style={{ position: 'absolute', inset: 0, zIndex: 230, background: 'rgba(20,17,15,0.28)', display: 'grid', placeItems: 'center', backdropFilter: 'blur(2px)', WebkitBackdropFilter: 'blur(2px)' }}>
          <div style={{ background: T.surface, borderRadius: T.radius.lg, padding: '24px 28px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, boxShadow: T.shadow.pop }}>
            <span style={{ width: 30, height: 30, borderRadius: 99, border: `3px solid ${T.lineSoft}`, borderTopColor: T.accent, animation: 'spin .8s linear infinite' }} />
            <div style={{ font: `600 13px/1.4 var(--f)`, color: T.sub, textAlign: 'center' }}>JANコードから<br />商品情報を取得中…</div>
          </div>
        </div>
      )}

      <BarcodeScanner open={!!scanMode} existing={existing} captureOnly={scanMode === 'attach'}
        onClose={() => setScanMode(null)}
        onAdopt={(c) => { setScanMode(null); pick(c); }}
        onAddNew={({ name, jan, unit, fromApi }) => { setScanMode(null); pickCustom(name, jan, unit, fromApi); }}
        onCapture={(jan) => { setScanMode(null); setPicked(p => (p ? { ...p, jan } : p)); }} />
    </div>
  );
}

function miniStep(T) {
  return { width: 40, height: 40, borderRadius: 11, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer' };
}

Object.assign(window, { MoveSheet, AddProduct, DatePick });
