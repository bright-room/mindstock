// screens-invite.jsx — household member invitation: invite link + QR + role, member management

// ── Deterministic pseudo-QR (real finder patterns + hashed data grid) ──
function QRCode({ value, size = 150, fg, bg }) {
  const T = useTheme();
  const FG = fg || T.ink;
  const BG = bg || '#ffffff';
  const ref = React.useRef(null);
  React.useEffect(() => {
    const cv = ref.current; if (!cv) return;
    const N = 25; // modules
    const quiet = 1; // quiet-zone modules
    const dpr = window.devicePixelRatio || 1;
    cv.width = size * dpr; cv.height = size * dpr;
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, size, size);
    const cell = size / (N + quiet * 2);
    const px = (n) => (n + quiet) * cell;
    // hash the value -> xorshift stream
    let h = 2166136261 >>> 0;
    for (let i = 0; i < value.length; i++) { h ^= value.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    const rand = () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; h >>>= 0; return h / 4294967295; };
    const inFinder = (r, c) => {
      const box = (br, bc) => r >= br && r < br + 7 && c >= bc && c < bc + 7;
      return box(0, 0) || box(0, N - 7) || box(N - 7, 0);
    };
    // data modules (rounded dots)
    ctx.fillStyle = FG;
    const rad = cell * 0.42;
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
      if (inFinder(r, c)) continue;
      if (rand() > 0.52) {
        ctx.beginPath();
        ctx.arc(px(c) + cell / 2, px(r) + cell / 2, rad, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    // finder patterns (rounded squares)
    const rrect = (x, y, w, r) => {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + w, r); ctx.arcTo(x + w, y + w, x, y + w, r);
      ctx.arcTo(x, y + w, x, y, r); ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
    };
    const finder = (br, bc) => {
      const x = px(bc), y = px(br);
      ctx.fillStyle = FG; rrect(x, y, 7 * cell, cell * 2.2); ctx.fill();
      ctx.fillStyle = BG; rrect(x + cell, y + cell, 5 * cell, cell * 1.6); ctx.fill();
      ctx.fillStyle = FG; rrect(x + cell * 2, y + cell * 2, 3 * cell, cell * 1.0); ctx.fill();
    };
    finder(0, 0); finder(0, N - 7); finder(N - 7, 0);
  }, [value, size, FG, BG]);
  return <canvas ref={ref} style={{ width: size, height: size, display: 'block' }} />;
}

// small icon-only copy/affordance button
function GhostIconBtn({ icon, onClick, active }) {
  const T = useTheme();
  const [press, setPress] = React.useState(false);
  return (
    <button onClick={onClick}
      onPointerDown={() => setPress(true)} onPointerUp={() => setPress(false)} onPointerLeave={() => setPress(false)}
      style={{ width: 42, height: 42, borderRadius: 12, flexShrink: 0, cursor: 'pointer',
        border: `1px solid ${active ? T.accent : T.line}`, background: active ? T.accentSoft : T.surface,
        color: active ? T.accent : T.sub, display: 'grid', placeItems: 'center',
        transition: 'transform .14s cubic-bezier(.2,.8,.2,1), background .2s, border-color .2s',
        transform: press ? 'scale(0.92)' : 'scale(1)' }}>
      <Icon name={icon} size={19} />
    </button>
  );
}

// ── Invite sheet ──
function InviteSheet({ open, onClose, store, householdName }) {
  const T = useTheme();
  const [tab, setTab] = React.useState('link'); // link | qr
  const [copied, setCopied] = React.useState(null); // 'link' | 'code' | null
  const inv = store.invite;
  const role = inv ? inv.role : 'member';

  // ensure an active link exists while the sheet is open; reset transient UI on open
  React.useEffect(() => {
    if (open) { setCopied(null); setTab('link'); if (!store.invite) store.createInvite('member'); }
  }, [open]);

  const link = inv ? joinLink(inv.code) : '';
  const copy = (what, text) => {
    try { if (navigator.clipboard) navigator.clipboard.writeText(text); } catch (e) {}
    setCopied(what);
    clearTimeout(copy._t); copy._t = setTimeout(() => setCopied(c => (c === what ? null : c)), 1900);
  };
  const share = () => {
    const text = `mindstock の「${householdName}」に招待します。\n${link}\nコード: ${inv ? inv.code : ''}`;
    if (navigator.share) { navigator.share({ title: 'mindstock 招待', text, url: 'https://' + link }).catch(() => {}); }
    else copy('link', link);
  };

  const expDays = inv ? Math.max(0, Math.ceil((inv.expiresAt - Date.now()) / 86400000)) : 0;

  return (
    <Sheet open={open} onClose={onClose} title="家族を招待" maxW={460}>
      <div style={{ font: `400 13.5px/1.65 var(--f)`, color: T.sub, margin: '-6px 0 18px' }}>
        「<b style={{ color: T.ink }}>{householdName}</b>」に招待して、在庫を一緒に管理しましょう。リンクかコードを送るだけです。
      </div>

      {/* role */}
      <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 2px 9px' }}>参加したときの権限</div>
      <Seg value={role} onChange={(v) => store.setInviteRole(v)} options={[
        { value: 'member', label: '編集できる', icon: 'pencil' },
        { value: 'viewer', label: '閲覧のみ', icon: 'eye' },
      ]} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, font: `400 12px/1.5 var(--f)`, color: T.faint, margin: '10px 2px 18px' }}>
        <Icon name={ROLES[role].icon} size={14} style={{ color: T.sub, flexShrink: 0 }} />
        <span>{ROLES[role].desc}</span>
      </div>

      {/* invite card */}
      <div style={{ background: T.surface2, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, padding: 6, marginBottom: 14 }}>
        <div style={{ padding: 4 }}>
          <Seg value={tab} onChange={setTab} options={[
            { value: 'link', label: 'リンク', icon: 'link' },
            { value: 'qr', label: 'QRコード', icon: 'qr' },
          ]} />
        </div>

        {tab === 'link' ? (
          <div style={{ padding: '6px 8px 10px' }}>
            {/* link row */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <div style={{ flex: 1, minWidth: 0, height: 42, display: 'flex', alignItems: 'center', padding: '0 14px',
                background: T.surface, border: `1px solid ${T.line}`, borderRadius: 12,
                font: `500 13.5px/1 ui-monospace, SFMono-Regular, Menlo, monospace`, color: T.ink,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{link}</div>
              <GhostIconBtn icon={copied === 'link' ? 'check' : 'copy'} active={copied === 'link'} onClick={() => copy('link', link)} />
            </div>
            <Btn full icon={copied === 'link' ? 'check' : 'link'} onClick={() => copy('link', link)}>
              {copied === 'link' ? 'コピーしました' : 'リンクをコピー'}
            </Btn>

            {/* code */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '16px 2px 2px' }}>
              <div style={{ height: 1, flex: 1, background: T.lineSoft }} />
              <span style={{ font: `500 11.5px/1 var(--f)`, color: T.faint }}>コードで参加もできます</span>
              <div style={{ height: 1, flex: 1, background: T.lineSoft }} />
            </div>
            <button onClick={() => copy('code', inv ? inv.code : '')} style={{
              width: '100%', marginTop: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12,
              background: 'transparent', border: 'none', cursor: 'pointer', padding: '4px 0' }}>
              <span style={{ font: `700 26px/1 ui-monospace, SFMono-Regular, Menlo, monospace`, letterSpacing: '0.22em',
                color: T.ink, paddingLeft: '0.22em' }}>{inv ? inv.code : '——————'}</span>
              <span style={{ color: copied === 'code' ? T.accent : T.faint, display: 'grid', placeItems: 'center' }}>
                <Icon name={copied === 'code' ? 'check' : 'copy'} size={18} />
              </span>
            </button>
          </div>
        ) : (
          <div style={{ padding: '14px 8px 16px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
            <div style={{ padding: 14, background: '#fff', borderRadius: 18, boxShadow: T.shadow.sm, border: `1px solid ${T.lineSoft}` }}>
              <QRCode value={link} size={158} fg={T.ink} bg="#ffffff" />
            </div>
            <div style={{ font: `500 12.5px/1.5 var(--f)`, color: T.faint, textAlign: 'center' }}>
              スマホのカメラで読み取って参加<br />
              <span style={{ font: `600 13px/1 ui-monospace, monospace`, letterSpacing: '0.12em', color: T.sub }}>{inv ? inv.code : ''}</span>
            </div>
          </div>
        )}
      </div>

      {/* validity + regenerate */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18, padding: '0 2px' }}>
        <Icon name="clock" size={15} style={{ color: T.faint, flexShrink: 0 }} />
        <span style={{ font: `500 12px/1.4 var(--f)`, color: T.faint, flex: 1 }}>あと{expDays}日間有効・何度でも使えます</span>
        <button onClick={() => { store.createInvite(role); setCopied(null); }} style={{
          font: `600 12.5px/1 var(--f)`, color: T.accent, background: 'none', border: 'none', cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', gap: 5 }}>
          <Icon name="add" size={15} />新しいリンク
        </button>
      </div>

      <Btn full size="lg" icon="share" variant="primary" onClick={share}>共有する</Btn>

      {/* demo affordance — simulate a join so the loop is visible in the prototype */}
      <button onClick={() => { store.acceptInvite(); onClose(); }} style={{
        width: '100%', marginTop: 12, background: 'none', border: 'none', cursor: 'pointer',
        font: `500 12px/1.4 var(--f)`, color: T.faint, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
        <Icon name="spark" size={13} />デモ：相手がリンクから参加したことにする
      </button>
    </Sheet>
  );
}

// ── Member management sheet ──
function MemberSheet({ open, member, isOwnerSelf, onClose, onChangeRole, onRemove }) {
  const T = useTheme();
  const [confirm, setConfirm] = React.useState(false);
  React.useEffect(() => { if (open) setConfirm(false); }, [open, member && member.id]);
  if (!member) return null;
  const isOwner = member.role === 'owner';
  const canManage = isOwnerSelf && !member.you;

  return (
    <Sheet open={open} onClose={onClose} title="メンバー" maxW={460}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: -4, marginBottom: 20 }}>
        <span style={{ width: 52, height: 52, borderRadius: 99, background: member.color, color: '#fff',
          font: `700 21px/1 var(--f)`, display: 'grid', placeItems: 'center', flexShrink: 0 }}>{member.initial}</span>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ font: `700 17px/1.2 var(--f)`, color: T.ink }}>{member.name}</span>
            {member.you && <span style={{ font: `600 10.5px/1 var(--f)`, color: T.sub, background: T.surface2, padding: '4px 7px', borderRadius: 6 }}>あなた</span>}
          </div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, font: `500 12.5px/1 var(--f)`, color: T.faint, marginTop: 7 }}>
            <Icon name={ROLES[member.role].icon} size={14} />{ROLES[member.role].label}
          </div>
        </div>
      </div>

      {isOwner ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', borderRadius: T.radius.md,
          background: T.accentSoft, color: T.accent, marginBottom: 6 }}>
          <Icon name="crown" size={18} style={{ flexShrink: 0 }} />
          <span style={{ font: `500 12.5px/1.5 var(--f)` }}>世帯のオーナーです。すべての在庫とメンバーを管理できます。</span>
        </div>
      ) : canManage ? (
        <React.Fragment>
          <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 2px 9px' }}>権限</div>
          <Seg value={member.role} onChange={(v) => onChangeRole(member.id, v)} options={[
            { value: 'member', label: '編集できる', icon: 'pencil' },
            { value: 'viewer', label: '閲覧のみ', icon: 'eye' },
          ]} />
          <div style={{ font: `400 12px/1.5 var(--f)`, color: T.faint, margin: '10px 2px 20px' }}>{ROLES[member.role].desc}</div>

          {confirm ? (
            <div style={{ background: T.status.out.soft, borderRadius: T.radius.md, padding: 16 }}>
              <div style={{ font: `600 13.5px/1.5 var(--f)`, color: T.status.out.color, marginBottom: 14 }}>
                {member.name} さんを世帯から外しますか？ 共有はすぐに解除されます。
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <Btn full variant="ghost" onClick={() => setConfirm(false)}>やめる</Btn>
                <Btn full variant="danger" icon="trash" onClick={() => { onRemove(member.id); onClose(); }}>外す</Btn>
              </div>
            </div>
          ) : (
            <Btn full variant="quiet" icon="trash" onClick={() => setConfirm(true)} style={{ color: T.status.out.color }}>世帯から外す</Btn>
          )}
        </React.Fragment>
      ) : (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', borderRadius: T.radius.md,
          background: T.surface2, color: T.sub, marginBottom: 6 }}>
          <Icon name="user" size={18} style={{ flexShrink: 0 }} />
          <span style={{ font: `500 12.5px/1.5 var(--f)` }}>権限の変更やメンバーの削除はオーナーのみ行えます。</span>
        </div>
      )}
    </Sheet>
  );
}

Object.assign(window, { QRCode, InviteSheet, MemberSheet, GhostIconBtn });
