// screens-a.jsx — Login splash + Stock home (在庫一覧)

function Login({ onLogin, onJoin }) {
  const T = useTheme();
  const [busy, setBusy] = React.useState(false);
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      padding: '0 28px', background: `linear-gradient(180deg, ${T.bg}, ${T.bgDeep})` }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 22 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 60, height: 60, borderRadius: 18, background: T.accent, color: T.onAccent,
            display: 'grid', placeItems: 'center', boxShadow: T.shadow.md, transform: 'rotate(-6deg)' }}>
            <Icon name="box" size={32} stroke={1.8} />
          </div>
          <div>
            <div style={{ font: `800 30px/1 var(--f)`, color: T.ink, letterSpacing: '-0.02em' }}>mindstock</div>
            <div style={{ font: `500 13.5px/1 var(--f)`, color: T.faint, marginTop: 7 }}>暮らしの在庫を、ちょうどよく。</div>
          </div>
        </div>
        <p style={{ font: `400 15px/1.7 var(--f)`, color: T.sub, margin: '6px 2px 0', maxWidth: 300 }}>
          買い忘れも、買い過ぎも減らす。日用品のストックを家族とゆるやかに共有する在庫ノート。
        </p>
        <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
          {['買い忘れ防止', '消費予測', '家族で共有'].map(t => (
            <span key={t} style={{ font: `600 12px/1 var(--f)`, color: T.sub, background: T.surface, whiteSpace: 'nowrap', flexShrink: 0,
              border: `1px solid ${T.line}`, padding: '8px 12px', borderRadius: 99 }}>{t}</span>
          ))}
        </div>
      </div>
      <div style={{ paddingBottom: 40 }}>
        <Btn full size="lg" disabled={busy}
          onClick={() => { setBusy(true); setTimeout(onLogin, 650); }}>
          {busy ? 'Zitadel に接続中…' : 'ログインして始める'}
        </Btn>
        <div style={{ font: `400 12px/1.5 var(--f)`, color: T.faint, textAlign: 'center', marginTop: 14 }}>
          Zitadel アカウントで安全にサインイン
        </div>
        {onJoin && (
          <button onClick={onJoin} style={{ width: '100%', marginTop: 16, background: 'none', border: 'none', cursor: 'pointer',
            color: T.faint, font: `500 12.5px/1 var(--f)`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Icon name="link" size={14} style={{ color: T.accent }} />招待リンクを開く（デモ）
          </button>
        )}
      </div>
    </div>
  );
}

function SummaryStrip({ products, onShop }) {
  const T = useTheme();
  const out = products.filter(p => statusOf(p) === 'out').length;
  const low = products.filter(p => statusOf(p) === 'low').length;
  const want = products.filter(p => statusOf(p) === 'ok' && p.wanted).length;
  const need = out + low + want;
  const soon = products.map(p => ({ p, d: predictDays(p) })).filter(x => x.d !== null && x.p.qty > 0)
    .sort((a, b) => a.d - b.d)[0];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 18 }}>
      <button onClick={onShop} style={{
        textAlign: 'left', border: 'none', cursor: 'pointer', padding: 18, borderRadius: T.radius.lg,
        background: need ? T.accent : T.surface, color: need ? T.onAccent : T.ink,
        boxShadow: need ? T.shadow.md : T.shadow.sm, display: 'flex', alignItems: 'center', gap: 14,
        transition: 'transform .15s', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ width: 44, height: 44, borderRadius: 13, display: 'grid', placeItems: 'center',
          background: need ? 'rgba(255,255,255,0.18)' : T.accentSoft, color: need ? T.onAccent : T.accent }}>
          <Icon name="cart" size={24} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ font: `700 16px/1.2 var(--f)` }}>
            {need ? `${need}点 買い物リストにあります` : '在庫はぜんぶ足りています'}
          </div>
          <div style={{ font: `500 12.5px/1.3 var(--f)`, opacity: 0.82, marginTop: 4 }}>
            {need ? `切らし ${out} ・ そろそろ ${low}${want ? ` ・ 自分で追加 ${want}` : ''}` : 'いまのところ補充は不要です'}
          </div>
        </div>
        <Icon name="chevR" size={20} style={{ opacity: 0.7 }} />
      </button>
      {soon && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 16px', borderRadius: T.radius.md,
          background: T.surface, border: `1px solid ${T.lineSoft}`, color: T.sub, font: `500 13px/1.3 var(--f)` }}>
          <Icon name="trend" size={17} style={{ color: T.accent }} />
          <span><b style={{ color: T.ink, fontWeight: 700 }}>{soon.p.name.split(' ')[0]}</b> はあと約 {soon.d} 日で切れる予測です</span>
        </div>
      )}
    </div>
  );
}

function ProductCard({ p, onReplenish, onConsume, onOpen }) {
  const T = useTheme();
  const st = statusOf(p);
  const days = predictDays(p);
  return (
    <div style={{
      background: T.surface, borderRadius: T.radius.lg, padding: 18, boxShadow: T.shadow.sm,
      border: `1px solid ${T.lineSoft}`, display: 'flex', flexDirection: 'column', gap: 14,
    }}>
      <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
        <Thumb icon={p.icon} image={p.image} size={48} />
        <button onClick={() => onOpen(p)} style={{ flex: 1, minWidth: 0, textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', padding: 0 }}>
          <div style={{ font: `600 15.5px/1.35 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
            <StatusDot status={st} withLabel />
            {st === 'ok' && p.wanted && (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, font: `600 11px/1 var(--f)`, color: T.accent, background: T.accentSoft, padding: '3px 7px', borderRadius: 6 }}>
                <Icon name="cart" size={12} stroke={2} />リスト
              </span>
            )}
            {days !== null && p.qty > 0 && (
              <span style={{ font: `500 12px/1 var(--f)`, color: T.faint, whiteSpace: 'nowrap' }}>· あと約{days}日</span>
            )}
          </div>
        </button>
        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{ font: `700 30px/0.9 var(--f)`, color: st === 'out' ? T.status.out.color : T.ink, fontFeatureSettings: '"tnum"' }}>{p.qty}</div>
          <div style={{ font: `500 11.5px/1 var(--f)`, color: T.faint, marginTop: 4, whiteSpace: 'nowrap' }}>{p.unit}</div>
        </div>
      </div>
      <StockBar qty={p.qty} min={p.min} status={st} />
      <div style={{ display: 'flex', gap: 9 }}>
        <Btn size="sm" variant="soft" icon="plus" full onClick={() => onReplenish(p)}>補充</Btn>
        <Btn size="sm" variant="ghost" icon="minus" full onClick={() => onConsume(p)}>消費</Btn>
      </div>
    </div>
  );
}

// compact card for multi-column grids
function CompactCard({ p, onReplenish, onConsume, onOpen }) {
  const T = useTheme();
  const st = statusOf(p);
  return (
    <div style={{
      background: T.surface, borderRadius: T.radius.lg, padding: 14, boxShadow: T.shadow.sm,
      border: `1px solid ${T.lineSoft}`, display: 'flex', flexDirection: 'column', gap: 11,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
        <Thumb icon={p.icon} image={p.image} size={40} radius={12} />
        <div style={{ textAlign: 'right' }}>
          <span style={{ font: `700 26px/0.9 var(--f)`, color: st === 'out' ? T.status.out.color : T.ink, fontFeatureSettings: '"tnum"' }}>{p.qty}</span>
          <span style={{ font: `500 11px/1 var(--f)`, color: T.faint, marginLeft: 4 }}>{p.unit}</span>
        </div>
      </div>
      <button onClick={() => onOpen(p)} style={{ textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', padding: 0 }}>
        <div style={{ font: `600 13.5px/1.35 var(--f)`, color: T.ink, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', minHeight: 37 }}>{p.name}</div>
        <div style={{ marginTop: 7, display: 'flex', alignItems: 'center', gap: 6 }}>
          <StatusDot status={st} withLabel />
          {st === 'ok' && p.wanted && <Icon name="cart" size={14} style={{ color: T.accent }} />}
        </div>
      </button>
      <StockBar qty={p.qty} min={p.min} status={st} />
      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={() => onReplenish(p)} style={compactBtn(T, 'soft')}><Icon name="plus" size={18} stroke={2.1} /></button>
        <button onClick={() => onConsume(p)} style={compactBtn(T, 'ghost')}><Icon name="minus" size={18} stroke={2.1} /></button>
      </div>
    </div>
  );
}

function compactBtn(T, v) {
  const base = { flex: 1, height: 38, borderRadius: 12, cursor: 'pointer', display: 'grid', placeItems: 'center', transition: 'transform .14s' };
  if (v === 'soft') return { ...base, border: '1px solid transparent', background: T.accentSoft, color: T.accent };
  return { ...base, border: `1px solid ${T.line}`, background: T.surface, color: T.sub };
}

function StockHome({ store, view, onView, onReplenish, onConsume, onOpen, onShop, onAdd, onBell, columns, desktop, onSwitch }) {
  const T = useTheme();
  const { displayName, householdName } = useUser();
  const { products } = store;
  const [q, setQ] = React.useState('');
  const ql = q.trim().toLowerCase();
  const searching = !!ql;
  const filtered = searching ? products.filter(p => p.name.toLowerCase().includes(ql)) : products;
  const cols = view === 'list' ? 1 : (columns || 2);
  return (
    <div>
      {!desktop && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <HouseholdPill name={householdName} count={store.members.length} onClick={onSwitch} />
          <button onClick={onBell} style={{ position: 'relative', width: 44, height: 44, borderRadius: 14, border: `1px solid ${T.line}`,
            background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer', boxShadow: T.shadow.sm, flexShrink: 0 }}>
            <Icon name="bell" size={21} />
            <span style={{ position: 'absolute', top: 9, right: 10, width: 8, height: 8, borderRadius: 99, background: T.status.out.color, border: `2px solid ${T.surface}` }} />
          </button>
        </div>
      )}
      <div style={{ marginBottom: 18 }}>
        <div style={{ font: `500 13px/1 var(--f)`, color: T.faint, whiteSpace: 'nowrap' }}>こんにちは、{displayName}</div>
        <div style={{ font: `800 25px/1.1 var(--f)`, color: T.ink, letterSpacing: '-0.02em', marginTop: 7 }}>在庫</div>
      </div>

      {!searching && <SummaryStrip products={products} onShop={onShop} />}

      {/* 在庫を名前で検索 */}
      <div style={{ position: 'relative', marginBottom: 14 }}>
        <Icon name="search" size={19} style={{ position: 'absolute', left: 14, top: 15, color: searching ? T.accent : T.faint }} />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="在庫を検索"
          style={{ width: '100%', height: 50, borderRadius: 14, border: `1px solid ${searching ? T.accent : T.line}`, background: T.surface,
            padding: '0 44px 0 42px', font: `400 15px/1 var(--f)`, color: T.ink, boxSizing: 'border-box', outline: 'none', boxShadow: T.shadow.sm }} />
        {q && (
          <button onClick={() => setQ('')} style={{ position: 'absolute', right: 8, top: 9, width: 32, height: 32, borderRadius: 9,
            border: 'none', background: T.surface2, color: T.sub, display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
            <Icon name="x" size={16} stroke={2.2} />
          </button>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ font: `600 13px/1 var(--f)`, color: T.sub }}>{searching ? `${filtered.length}件 見つかりました` : `すべて · ${products.length}点`}</div>
        <div style={{ width: 96 }}>
          <Seg value={view} onChange={onView} options={[{ value: 'grid', icon: 'grid' }, { value: 'list', icon: 'list' }]} />
        </div>
      </div>

      {searching && filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 20px' }}>
          <div style={{ width: 56, height: 56, borderRadius: 18, background: T.surface2, color: T.faint, display: 'grid', placeItems: 'center', margin: '0 auto 14px' }}><Icon name="search" size={26} /></div>
          <div style={{ font: `700 15.5px/1.4 var(--f)`, color: T.ink }}>「{q.trim()}」に一致する在庫はありません</div>
          <div style={{ font: `400 13px/1.5 var(--f)`, color: T.faint, marginTop: 7 }}>名前を変えて検索するか、新しく商品を追加できます。</div>
          <div style={{ marginTop: 16 }}><Btn icon="plus" onClick={onAdd}>商品を追加</Btn></div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, gap: 13 }}>
          {filtered.map(p => (view === 'grid'
            ? <CompactCard key={p.id} p={p} onReplenish={onReplenish} onConsume={onConsume} onOpen={onOpen} />
            : <ProductCard key={p.id} p={p} onReplenish={onReplenish} onConsume={onConsume} onOpen={onOpen} />
          ))}
          {!searching && (
            <button onClick={onAdd} style={{
              gridColumn: cols > 1 ? '1 / -1' : 'auto', height: 58, borderRadius: T.radius.lg,
              border: `1.5px dashed ${T.line}`, background: 'transparent', color: T.sub, cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, font: `600 14px/1 var(--f)`,
            }}>
              <Icon name="plus" size={18} />商品を追加
            </button>
          )}
        </div>
      )}
      <div style={{ height: 8 }} />
    </div>
  );
}

Object.assign(window, { Login, StockHome, ProductCard, SummaryStrip });
