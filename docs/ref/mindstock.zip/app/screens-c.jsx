// screens-c.jsx — Shopping list, Product detail (history + correction), Profile, Notifications

function ShoppingList({ store, onReplenish, onOpen }) {
  const T = useTheme();
  const { products } = store;
  const [done, setDone] = React.useState({});
  const [addOpen, setAddOpen] = React.useState(false);

  const auto = products.filter(p => statusOf(p) !== 'ok')
    .sort((a, b) => (statusOf(a) === 'out' ? 0 : 1) - (statusOf(b) === 'out' ? 0 : 1));
  const manual = products.filter(p => statusOf(p) === 'ok' && p.wanted);
  const items = [...auto, ...manual];
  const remaining = items.filter(p => !done[p.id]).length;
  // 在庫から探して追加できる候補（まだリストに載っていない採用済み商品）
  const addable = products.filter(p => !onShoppingList(p));

  const Row = (p, isManual) => {
    const st = statusOf(p);
    const isDone = done[p.id];
    const shortage = Math.max(1, p.min - p.qty + (st === 'out' ? p.min : 0));
    return (
      <div key={p.id} style={{
        display: 'flex', alignItems: 'center', gap: 13, padding: 14, borderRadius: T.radius.lg,
        background: T.surface, border: `1px solid ${T.lineSoft}`, boxShadow: isDone ? 'none' : T.shadow.sm,
        opacity: isDone ? 0.5 : 1, transition: 'opacity .25s',
      }}>
        <button onClick={() => setDone(d => ({ ...d, [p.id]: !d[p.id] }))} style={{
          width: 28, height: 28, borderRadius: 99, flexShrink: 0, cursor: 'pointer',
          border: `2px solid ${isDone ? T.accent : T.line}`, background: isDone ? T.accent : 'transparent',
          color: T.onAccent, display: 'grid', placeItems: 'center', transition: 'all .2s',
        }}>{isDone && <Icon name="check" size={16} stroke={2.8} />}</button>
        <button onClick={() => onOpen(p)} style={{ flex: 1, minWidth: 0, textAlign: 'left', border: 'none', background: 'none', padding: 0, cursor: 'pointer' }}>
          <div style={{ font: `600 15px/1.3 var(--f)`, color: T.ink, textDecoration: isDone ? 'line-through' : 'none',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 5 }}>
            {isManual ? (
              <React.Fragment>
                <span style={{ font: `600 10.5px/1 var(--f)`, color: T.accent, background: T.accentSoft, padding: '3px 7px', borderRadius: 6 }}>自分で追加</span>
                <span style={{ font: `500 12px/1 var(--f)`, color: T.faint }}>在庫 {p.qty}{p.unit}</span>
              </React.Fragment>
            ) : (
              <React.Fragment>
                <StatusDot status={st} withLabel />
                <span style={{ font: `500 12px/1 var(--f)`, color: T.faint }}>· 目安 {shortage}{p.unit}</span>
              </React.Fragment>
            )}
          </div>
        </button>
        {isManual && (
          <button onClick={() => store.setWanted(p.id, false)} title="リストから外す" style={{
            width: 30, height: 30, borderRadius: 9, flexShrink: 0, cursor: 'pointer',
            border: `1px solid ${T.line}`, background: T.surface, color: T.faint, display: 'grid', placeItems: 'center' }}>
            <Icon name="x" size={15} stroke={2.2} />
          </button>
        )}
        <Btn size="sm" variant="soft" icon="plus" onClick={() => onReplenish(p)}>補充</Btn>
      </div>
    );
  };

  return (
    <div>
      <div style={{ marginBottom: 18 }}>
        <div style={{ font: `500 13px/1 var(--f)`, color: T.faint }}>在庫が少ない商品と、自分で追加した商品</div>
        <div style={{ font: `800 25px/1.1 var(--f)`, color: T.ink, letterSpacing: '-0.02em', marginTop: 7 }}>買い物リスト</div>
      </div>

      {/* B: 在庫から探して追加 */}
      <button onClick={() => setAddOpen(true)} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12,
        padding: '13px 15px', borderRadius: T.radius.md, cursor: 'pointer', textAlign: 'left',
        border: `1px dashed ${T.line}`, background: T.surface, marginBottom: 16 }}>
        <span style={{ width: 34, height: 34, borderRadius: 10, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
          <Icon name="search" size={18} />
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: `600 14px/1.2 var(--f)`, color: T.ink }}>在庫から探して追加</div>
          <div style={{ font: `500 11.5px/1.3 var(--f)`, color: T.faint, marginTop: 3 }}>在庫はあるけど買い足したい商品を選ぶ</div>
        </div>
        <Icon name="plus" size={18} style={{ color: T.faint, flexShrink: 0 }} />
      </button>

      {items.length === 0 ? (
        <EmptyState icon="check" title="買うものはありません" sub="在庫はぜんぶ足りています。買い足したい物は上から追加できます。" />
      ) : (
        <React.Fragment>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: T.radius.md,
            background: T.accent, color: T.onAccent, marginBottom: 16, boxShadow: T.shadow.md }}>
            <Icon name="cart" size={22} />
            <div style={{ font: `700 15px/1.2 var(--f)`, flex: 1 }}>あと {remaining} 点で買い物完了</div>
            <div style={{ font: `700 18px/1 var(--f)`, fontFeatureSettings: '"tnum"' }}>{items.length - remaining}/{items.length}</div>
          </div>

          {auto.length > 0 && (
            <React.Fragment>
              {manual.length > 0 && <div style={{ font: `700 12px/1 var(--f)`, color: T.faint, margin: '4px 4px 10px' }}>在庫が少ない</div>}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>{auto.map(p => Row(p, false))}</div>
            </React.Fragment>
          )}
          {manual.length > 0 && (
            <React.Fragment>
              <div style={{ font: `700 12px/1 var(--f)`, color: T.faint, margin: `${auto.length > 0 ? 22 : 4}px 4px 10px` }}>自分で追加</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>{manual.map(p => Row(p, true))}</div>
            </React.Fragment>
          )}
        </React.Fragment>
      )}
      <div style={{ height: 8 }} />

      <AddToListSheet open={addOpen} candidates={addable} onClose={() => setAddOpen(false)} onAdd={(pid) => store.setWanted(pid, true)} />
    </div>
  );
}

// 在庫（採用済み商品）から探して買い物リストに足すシート
function AddToListSheet({ open, candidates, onClose, onAdd }) {
  const T = useTheme();
  const [q, setQ] = React.useState('');
  const [added, setAdded] = React.useState({});
  React.useEffect(() => { if (open) { setQ(''); setAdded({}); } }, [open]);
  const results = candidates.filter(p => !q || p.name.includes(q));
  return (
    <Sheet open={open} onClose={onClose} title="在庫から追加">
      <div style={{ position: 'relative', marginBottom: 14 }}>
        <Icon name="search" size={19} style={{ position: 'absolute', left: 14, top: 14, color: T.faint }} />
        <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="在庫の商品名で検索"
          style={{ width: '100%', height: 48, borderRadius: 13, border: `1px solid ${T.line}`, background: T.surface,
            padding: '0 14px 0 42px', font: `400 15px/1 var(--f)`, color: T.ink, boxSizing: 'border-box', outline: 'none' }} />
      </div>
      {results.length === 0 ? (
        <div style={{ font: `400 13px/1.6 var(--f)`, color: T.faint, textAlign: 'center', padding: '24px 8px' }}>
          {candidates.length === 0 ? 'すべての在庫がすでに買い物リストにあります。' : '該当する在庫がありません。'}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 360, overflowY: 'auto', margin: '0 -4px', padding: '0 4px' }}>
          {results.map(p => {
            const isAdded = added[p.id];
            return (
              <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 13px', borderRadius: T.radius.md,
                border: `1px solid ${T.lineSoft}`, background: T.surface }}>
                <Thumb icon={p.icon} image={p.image} size={40} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `600 14px/1.3 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                  <div style={{ font: `500 11.5px/1 var(--f)`, color: T.faint, marginTop: 4 }}>在庫 {p.qty}{p.unit}</div>
                </div>
                <button onClick={() => { if (!isAdded) { onAdd(p.id); setAdded(a => ({ ...a, [p.id]: true })); } }} disabled={isAdded}
                  style={{ height: 36, padding: isAdded ? '0 12px' : '0 14px', borderRadius: 10, flexShrink: 0, cursor: isAdded ? 'default' : 'pointer',
                    border: 'none', font: `600 13px/1 var(--f)`, display: 'inline-flex', alignItems: 'center', gap: 6,
                    background: isAdded ? T.surface2 : T.accent, color: isAdded ? T.sub : T.onAccent }}>
                  {isAdded ? <React.Fragment><Icon name="check" size={15} stroke={2.6} />追加済み</React.Fragment> : <React.Fragment><Icon name="plus" size={15} stroke={2.4} />追加</React.Fragment>}
                </button>
              </div>
            );
          })}
        </div>
      )}
      <div style={{ marginTop: 16 }}><Btn full variant="ghost" onClick={onClose}>閉じる</Btn></div>
    </Sheet>
  );
}

function EmptyState({ icon, title, sub }) {
  const T = useTheme();
  return (
    <div style={{ textAlign: 'center', padding: '56px 20px' }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: T.accentSoft, color: T.accent,
        display: 'grid', placeItems: 'center', margin: '0 auto 16px' }}><Icon name={icon} size={30} /></div>
      <div style={{ font: `700 17px/1.3 var(--f)`, color: T.ink }}>{title}</div>
      <div style={{ font: `400 13.5px/1.5 var(--f)`, color: T.faint, marginTop: 7 }}>{sub}</div>
    </div>
  );
}

// ── Product detail (full screen) with history + correction ──
function ProductDetail({ open, product, history, onClose, onReplenish, onConsume, onSettings, onCorrect, onToggleWanted, canEdit }) {
  const T = useTheme();
  const [show, setShow] = React.useState(false);
  const [correcting, setCorrecting] = React.useState(null);
  React.useEffect(() => { if (open) requestAnimationFrame(() => setShow(true)); else { setShow(false); setCorrecting(null); } }, [open]);
  if (!open || !product) return null;
  const st = statusOf(product);
  const days = predictDays(product);
  const entries = history[product.id] || [];
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 210, background: T.bg,
      transform: show ? 'translateX(0)' : 'translateX(100%)', transition: 'transform .36s cubic-bezier(.2,.9,.25,1)',
      display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 18px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={onClose} style={navBtn(T)}><Icon name="chevL" size={20} /></button>
        {canEdit
          ? <button onClick={() => onSettings(product)} style={navBtn(T)}><Icon name="sliders" size={19} /></button>
          : <span style={{ width: 42 }} />}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 20px 28px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 12, marginBottom: 22 }}>
          <Thumb icon={product.icon} image={product.image} size={72} radius={22} />
          <div style={{ font: `700 19px/1.35 var(--f)`, color: T.ink, maxWidth: 280 }}>{product.name}</div>
        </div>

        <div style={{ background: T.surface, borderRadius: T.radius.lg, padding: 22, boxShadow: T.shadow.sm, border: `1px solid ${T.lineSoft}`, marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 16 }}>
            <div>
              <div style={{ font: `700 46px/0.9 var(--f)`, color: st === 'out' ? T.status.out.color : T.ink, fontFeatureSettings: '"tnum"' }}>
                {product.qty}<span style={{ font: `500 16px/1 var(--f)`, color: T.faint, marginLeft: 6 }}>{product.unit}</span>
              </div>
              <div style={{ marginTop: 10 }}><StatusDot status={st} withLabel /></div>
            </div>
            <div style={{ textAlign: 'right', font: `500 12.5px/1.5 var(--f)`, color: T.faint }}>
              <div>最低在庫 {product.min}{product.unit}</div>
              {days !== null && product.qty > 0 && <div style={{ color: T.accent, fontWeight: 600, marginTop: 4 }}>あと約{days}日</div>}
            </div>
          </div>
          <StockBar qty={product.qty} min={product.min} status={st} />
          <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
            <Btn full variant="soft" icon="plus" onClick={() => onReplenish(product)}>補充</Btn>
            <Btn full variant="ghost" icon="minus" onClick={() => onConsume(product)}>消費</Btn>
          </div>
          <div style={{ marginTop: 12, paddingTop: 14, borderTop: `1px solid ${T.lineSoft}` }}>
            {st !== 'ok' ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 13px', borderRadius: T.radius.md, background: T.surface2 }}>
                <Icon name="cart" size={18} style={{ color: T.sub, flexShrink: 0 }} />
                <span style={{ font: `600 12.5px/1.4 var(--f)`, color: T.sub }}>在庫が少ないため、買い物リストに表示中です</span>
              </div>
            ) : product.wanted ? (
              <Btn full variant="soft" icon="cart" onClick={() => onToggleWanted(product.id, false)}>買い物リストから外す</Btn>
            ) : (
              <Btn full variant="ghost" icon="cart" onClick={() => onToggleWanted(product.id, true)}>買い物リストに入れる</Btn>
            )}
          </div>
        </div>

        <div style={{ font: `700 14px/1 var(--f)`, color: T.ink, margin: '20px 4px 14px' }}>履歴</div>
        {entries.length === 0 ? (
          <div style={{ font: `400 13px/1.5 var(--f)`, color: T.faint, padding: '10px 4px' }}>まだ記録がありません。</div>
        ) : (
          <div style={{ position: 'relative', paddingLeft: 6 }}>
            {entries.map((e, i) => (
              <HistoryRow key={e.id} e={e} unit={product.unit} last={i === entries.length - 1} onCorrect={() => setCorrecting(e)} />
            ))}
          </div>
        )}
      </div>

      <CorrectionSheet open={!!correcting} entry={correcting} unit={product.unit} onClose={() => setCorrecting(null)}
        onSubmit={(qty, reason) => { onCorrect(product.id, correcting.id, qty, reason); setCorrecting(null); }} />
    </div>
  );
}

function HistoryRow({ e, unit, last, onCorrect }) {
  const T = useTheme();
  const isRep = e.kind === 'replenish';
  const u = USERS[e.by] || USERS.me;
  return (
    <div style={{ display: 'flex', gap: 14, paddingBottom: last ? 0 : 18, position: 'relative' }}>
      {!last && <div style={{ position: 'absolute', left: 17, top: 36, bottom: 0, width: 2, background: T.lineSoft }} />}
      <div style={{ width: 36, height: 36, borderRadius: 12, flexShrink: 0, display: 'grid', placeItems: 'center', zIndex: 1,
        background: isRep ? T.accentSoft : T.surface2, color: isRep ? T.accent : T.sub, border: `1px solid ${T.lineSoft}` }}>
        <Icon name={isRep ? 'plus' : 'minus'} size={18} stroke={2.2} />
      </div>
      <div style={{ flex: 1, paddingTop: 1 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8 }}>
          <div style={{ font: `600 14.5px/1.3 var(--f)`, color: T.ink }}>
            {isRep ? '補充' : '消費'} <span style={{ fontFeatureSettings: '"tnum"' }}>{e.qty}</span>{unit}
            {e.corrected && <span style={{ font: `600 10.5px/1 var(--f)`, color: T.accent, background: T.accentSoft, padding: '3px 6px', borderRadius: 6, marginLeft: 8 }}>訂正済</span>}
          </div>
          <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, flexShrink: 0 }}>{relTime(e.occurredAt)}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 7 }}>
          <span style={{ width: 18, height: 18, borderRadius: 99, background: u.color, color: '#fff', font: `700 9px/1 var(--f)`, display: 'grid', placeItems: 'center' }}>{u.initial}</span>
          <span style={{ font: `500 12px/1 var(--f)`, color: T.faint }}>{u.name}{e.note ? ` · ${e.note}` : ''}</span>
          <button onClick={onCorrect} style={{ marginLeft: 'auto', font: `600 12px/1 var(--f)`, color: T.accent, background: 'none', border: 'none', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icon name="pencil" size={13} />訂正
          </button>
        </div>
      </div>
    </div>
  );
}

function CorrectionSheet({ open, entry, unit, onClose, onSubmit }) {
  const T = useTheme();
  const [qty, setQty] = React.useState(1);
  const [reason, setReason] = React.useState('');
  React.useEffect(() => { if (open && entry) { setQty(entry.qty); setReason(''); } }, [open, entry]);
  if (!entry) return null;
  return (
    <Sheet open={open} onClose={onClose} title="数量を訂正" maxW={460}>
      <div style={{ font: `400 13px/1.6 var(--f)`, color: T.sub, marginBottom: 18 }}>
        元の記録は消えません。「{entry.kind === 'replenish' ? '補充' : '消費'} {entry.qty}{unit}」を訂正した、という事実が新しく残ります。
      </div>
      <div style={{ marginBottom: 20 }}><Stepper value={qty} onChange={setQty} unit={unit} /></div>
      <input value={reason} onChange={e => setReason(e.target.value)} placeholder="訂正の理由（入力推奨）"
        style={{ width: '100%', height: 46, borderRadius: 12, border: `1px solid ${reason ? T.line : T.status.low.color}`, background: T.surface,
          padding: '0 14px', font: `400 14px/1 var(--f)`, color: T.ink, marginBottom: 18, boxSizing: 'border-box', outline: 'none' }} />
      <Btn full size="lg" disabled={!reason} onClick={() => onSubmit(qty, reason)}>訂正を記録する</Btn>
    </Sheet>
  );
}

// ── Notifications (future-vision) ──
function NotifSheet({ open, products, onClose, onOpen }) {
  const T = useTheme();
  const alerts = products.map(p => ({ p, st: statusOf(p), d: predictDays(p) }))
    .filter(x => x.st !== 'ok' || (x.d !== null && x.d <= 5 && x.p.qty > 0))
    .slice(0, 6);
  return (
    <Sheet open={open} onClose={onClose} title="お知らせ">
      <div style={{ font: `400 12px/1.5 var(--f)`, color: T.faint, marginBottom: 16, marginTop: -8 }}>
        在庫減少のお知らせ（将来は Web Push で端末に通知）
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
        {alerts.map(({ p, st, d }) => (
          <button key={p.id} onClick={() => { onClose(); onOpen(p); }} style={{
            display: 'flex', alignItems: 'center', gap: 12, padding: 13, borderRadius: T.radius.md, cursor: 'pointer',
            border: `1px solid ${T.lineSoft}`, background: T.surface, textAlign: 'left' }}>
            <div style={{ width: 38, height: 38, borderRadius: 11, display: 'grid', placeItems: 'center', flexShrink: 0,
              background: (T.status[st] || T.status.ok).soft, color: (T.status[st] || T.status.ok).color }}>
              <Icon name={st === 'out' ? 'cart' : 'trend'} size={19} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: `600 14px/1.3 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
              <div style={{ font: `500 12px/1.3 var(--f)`, color: T.faint, marginTop: 4 }}>
                {st === 'out' ? '在庫を切らしています' : st === 'low' ? 'そろそろ補充どきです' : `あと約${d}日で切れそうです`}
              </div>
            </div>
            <Icon name="chevR" size={17} style={{ color: T.faint }} />
          </button>
        ))}
      </div>
    </Sheet>
  );
}

function navBtn(T) {
  return { width: 42, height: 42, borderRadius: 13, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer', boxShadow: T.shadow.sm };
}

Object.assign(window, { ShoppingList, ProductDetail, CorrectionSheet, NotifSheet, EmptyState, HistoryRow });
