// core.jsx — design tokens (themes), icons, theme context, shared UI atoms
// Exports to window at the bottom.

// ─────────────────────────────────────────────────────────────
// Tones — neutral + 1 accent. L/C held close, hue varied.
// Stock STATUS uses semantic amber/red only for attention; "ok" stays calm.
// ─────────────────────────────────────────────────────────────
const TONES = {
  clay: {
    label: 'Clay',
    bg:       'oklch(0.964 0.008 74)',
    bgDeep:   'oklch(0.935 0.011 72)',
    surface:  'oklch(0.995 0.004 78)',
    surface2: 'oklch(0.978 0.007 76)',
    ink:      'oklch(0.27 0.013 58)',
    sub:      'oklch(0.50 0.013 58)',
    faint:    'oklch(0.66 0.010 60)',
    line:     'oklch(0.90 0.008 70)',
    lineSoft: 'oklch(0.93 0.006 70)',
    accent:   'oklch(0.62 0.132 41)',
    accentHi: 'oklch(0.67 0.135 45)',
    accentSoft:'oklch(0.935 0.038 52)',
    onAccent: 'oklch(0.99 0.01 80)',
  },
  indigo: {
    label: 'Indigo',
    bg:       'oklch(0.969 0.006 262)',
    bgDeep:   'oklch(0.938 0.010 262)',
    surface:  'oklch(0.997 0.002 262)',
    surface2: 'oklch(0.980 0.006 262)',
    ink:      'oklch(0.27 0.022 268)',
    sub:      'oklch(0.50 0.020 268)',
    faint:    'oklch(0.66 0.016 268)',
    line:     'oklch(0.905 0.010 262)',
    lineSoft: 'oklch(0.935 0.007 262)',
    accent:   'oklch(0.55 0.145 268)',
    accentHi: 'oklch(0.60 0.150 268)',
    accentSoft:'oklch(0.935 0.042 268)',
    onAccent: 'oklch(0.99 0.005 268)',
  },
  pine: {
    label: 'Pine',
    bg:       'oklch(0.970 0.007 154)',
    bgDeep:   'oklch(0.940 0.012 154)',
    surface:  'oklch(0.996 0.003 154)',
    surface2: 'oklch(0.979 0.008 154)',
    ink:      'oklch(0.26 0.016 162)',
    sub:      'oklch(0.49 0.016 160)',
    faint:    'oklch(0.65 0.013 158)',
    line:     'oklch(0.903 0.011 156)',
    lineSoft: 'oklch(0.933 0.008 156)',
    accent:   'oklch(0.53 0.104 158)',
    accentHi: 'oklch(0.58 0.108 158)',
    accentSoft:'oklch(0.930 0.040 156)',
    onAccent: 'oklch(0.99 0.008 156)',
  },
};

// semantic status (shared)
const STATUS = {
  ok:   { key: 'ok',   label: '十分',     color: 'oklch(0.58 0.07 168)',  soft: 'oklch(0.945 0.03 168)' },
  low:  { key: 'low',  label: 'そろそろ', color: 'oklch(0.70 0.12 72)',   soft: 'oklch(0.95 0.045 80)'  },
  out:  { key: 'out',  label: '切らし中', color: 'oklch(0.585 0.16 28)',  soft: 'oklch(0.945 0.038 32)' },
};

function makeTheme(toneKey) {
  const t = TONES[toneKey] || TONES.clay;
  return {
    ...t,
    tone: toneKey,
    status: STATUS,
    radius: { sm: 12, md: 16, lg: 22, xl: 28 },
    shadow: {
      sm: '0 1px 2px rgba(40,33,28,0.05), 0 1px 1px rgba(40,33,28,0.04)',
      md: '0 1px 2px rgba(40,33,28,0.05), 0 6px 16px -6px rgba(40,33,28,0.14)',
      lg: '0 2px 4px rgba(40,33,28,0.05), 0 18px 40px -12px rgba(40,33,28,0.22)',
      pop: '0 1px 2px rgba(40,33,28,0.06), 0 24px 60px -16px rgba(40,33,28,0.30)',
    },
  };
}

const ThemeCtx = React.createContext(makeTheme('clay'));
const useTheme = () => React.useContext(ThemeCtx);

const UserCtx = React.createContext({ displayName: 'あなた', householdName: 'わたしの家' });
const useUser = () => React.useContext(UserCtx);

// ─────────────────────────────────────────────────────────────
// Icons — simple line glyphs (stroke="currentColor")
// ─────────────────────────────────────────────────────────────
function Icon({ name, size = 22, stroke = 1.7, style = {} }) {
  const p = { fill: 'none', stroke: 'currentColor', strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    box:    <g {...p}><path d="M3 8l9-5 9 5v8l-9 5-9-5V8z"/><path d="M3 8l9 5 9-5M12 13v8"/></g>,
    cart:   <g {...p}><circle cx="9" cy="20" r="1.2"/><circle cx="18" cy="20" r="1.2"/><path d="M2.5 3.5h2l2.2 11.2a1.5 1.5 0 0 0 1.5 1.2h8.1a1.5 1.5 0 0 0 1.5-1.2L20.5 7H6"/></g>,
    plus:   <g {...p}><path d="M12 5v14M5 12h14"/></g>,
    minus:  <g {...p}><path d="M5 12h14"/></g>,
    clock:  <g {...p}><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></g>,
    user:   <g {...p}><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.2-3.7 4-5.5 7.5-5.5s6.3 1.8 7.5 5.5"/></g>,
    bell:   <g {...p}><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6z"/><path d="M10 20a2 2 0 0 0 4 0"/></g>,
    search: <g {...p}><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></g>,
    chevR:  <g {...p}><path d="M9 5l7 7-7 7"/></g>,
    chevL:  <g {...p}><path d="M15 5l-7 7 7 7"/></g>,
    chevD:  <g {...p}><path d="M6 9l6 6 6-6"/></g>,
    users:  <g {...p}><circle cx="9" cy="8" r="3.2"/><path d="M3.4 19c.9-3 3-4.6 5.6-4.6S13.7 16 14.6 19"/><path d="M16.2 5.1a3 3 0 0 1 0 5.7M17.8 19c-.25-1.9-1-3.3-2.1-4.2"/></g>,
    swap:   <g {...p}><path d="M4 8h13l-3-3M20 16H7l3 3"/></g>,
    check:  <g {...p}><path d="M5 12.5l4.5 4.5L19 6.5"/></g>,
    x:      <g {...p}><path d="M6 6l12 12M18 6L6 18"/></g>,
    archive:<g {...p}><rect x="3.5" y="5" width="17" height="4" rx="1.2"/><path d="M5 9v9.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9M10 13h4"/></g>,
    sliders:<g {...p}><path d="M4 8h10M18 8h2M4 16h2M10 16h10"/><circle cx="16" cy="8" r="2"/><circle cx="8" cy="16" r="2"/></g>,
    cal:    <g {...p}><rect x="4" y="5" width="16" height="16" rx="2.5"/><path d="M4 9.5h16M8 3.5v3.5M16 3.5v3.5"/></g>,
    pencil: <g {...p}><path d="M5 19l1-4L16.5 4.5a1.8 1.8 0 0 1 2.6 0l.4.4a1.8 1.8 0 0 1 0 2.6L9 18l-4 1z"/></g>,
    leaf:   <g {...p}><path d="M5 19C5 11 11 5 20 5c0 9-6 15-14 15a5 5 0 0 1-1-7"/><path d="M9 15c3-3 6-4 9-5"/></g>,
    drop:   <g {...p}><path d="M12 3.5C12 3.5 5.5 10 5.5 14.5a6.5 6.5 0 0 0 13 0C18.5 10 12 3.5 12 3.5z"/></g>,
    spark:  <g {...p}><path d="M12 3l1.8 5.4L19 10l-5.2 1.6L12 17l-1.8-5.4L5 10l5.2-1.6L12 3z"/></g>,
    home:   <g {...p}><path d="M4 11l8-7 8 7M6 9.5V20h12V9.5"/></g>,
    bolt:   <g {...p}><path d="M13 3L5 13h5l-1 8 8-10h-5l1-8z"/></g>,
    trend:  <g {...p}><path d="M4 16l5-5 3.5 3.5L20 7M20 7h-4M20 7v4"/></g>,
    grid:   <g {...p}><rect x="4" y="4" width="7" height="7" rx="1.6"/><rect x="13" y="4" width="7" height="7" rx="1.6"/><rect x="4" y="13" width="7" height="7" rx="1.6"/><rect x="13" y="13" width="7" height="7" rx="1.6"/></g>,
    list:   <g {...p}><path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/></g>,
    bottle: <g {...p}><path d="M10 3h4v2.5l1.2 2.4a3 3 0 0 1 .3 1.3V19a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V9.2a3 3 0 0 1 .3-1.3L10 5.5V3z"/><path d="M9 12.5h6"/></g>,
    paper:  <g {...p}><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3"/><path d="M12 3.5v5M12 15.5v5M3.5 12h5M15.5 12h5"/></g>,
    egg:    <g {...p}><path d="M12 3c3.5 0 6 5 6 9a6 6 0 0 1-12 0c0-4 2.5-9 6-9z"/></g>,
    salt:   <g {...p}><path d="M8 9h8l-1 11H9L8 9z"/><path d="M9 9V6a3 3 0 0 1 6 0v3M11 4.5h2"/></g>,
    link:   <g {...p}><path d="M10 13.5a4 4 0 0 0 5.66 0l3-3a4 4 0 1 0-5.66-5.66l-1.6 1.6"/><path d="M14 10.5a4 4 0 0 0-5.66 0l-3 3a4 4 0 1 0 5.66 5.66l1.6-1.6"/></g>,
    copy:   <g {...p}><rect x="8.5" y="8.5" width="11" height="11" rx="2.5"/><path d="M5.5 15.5H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v.5"/></g>,
    qr:     <g {...p}><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="M14 14h2.5v2.5M20 14v2.5M14 20h2.5M20 17.5V20h-2.5"/></g>,
    crown:  <g {...p}><path d="M4 17h16M5 8l3 3 4-5 4 5 3-3-1.7 9H6.7L5 8z"/></g>,
    eye:    <g {...p}><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></g>,
    trash:  <g {...p}><path d="M4 7h16M9 7V5.4A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.4V7M6.5 7l1 12.1a1.5 1.5 0 0 0 1.5 1.4h6a1.5 1.5 0 0 0 1.5-1.4L17.5 7M10 11v6M14 11v6"/></g>,
    share:  <g {...p}><circle cx="6" cy="12" r="2.4"/><circle cx="17" cy="6" r="2.4"/><circle cx="17" cy="18" r="2.4"/><path d="M8.1 10.9l6.8-3.8M8.1 13.1l6.8 3.8"/></g>,
    add:    <g {...p}><circle cx="12" cy="12" r="8.5"/><path d="M12 8.5v7M8.5 12h7"/></g>,
    barcode:<g {...p}><path d="M4 6.5v11M7 6.5v11M9.5 6.5v11M12.5 6.5v11M15 6.5v11M17.5 6.5v11M20 6.5v11"/></g>,
    scan:   <g {...p}><path d="M4 8.5V6.5A2.5 2.5 0 0 1 6.5 4h2M15.5 4h2A2.5 2.5 0 0 1 20 6.5v2M20 15.5v2a2.5 2.5 0 0 1-2.5 2.5h-2M8.5 20h-2A2.5 2.5 0 0 1 4 17.5v-2"/><path d="M3.5 12h17"/></g>,
    camera: <g {...p}><path d="M4 8h2.5L8 5.8h8L17.5 8H20a1.2 1.2 0 0 1 1.2 1.2v8.6A1.2 1.2 0 0 1 20 19H4a1.2 1.2 0 0 1-1.2-1.2V9.2A1.2 1.2 0 0 1 4 8z"/><circle cx="12" cy="13" r="3.3"/></g>,
    keyboard:<g {...p}><rect x="3" y="7" width="18" height="11" rx="2.2"/><path d="M6.5 10.5h.01M10 10.5h.01M13.5 10.5h.01M17 10.5h.01M6.5 13.5h.01M17 13.5h.01M9 13.5h6"/></g>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={{ display: 'block', flexShrink: 0, ...style }}>
      {paths[name] || paths.box}
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Atoms
// ─────────────────────────────────────────────────────────────
function Btn({ children, onClick, variant = 'primary', size = 'md', icon, full, style = {}, disabled }) {
  const T = useTheme();
  const [press, setPress] = React.useState(false);
  const sizes = { sm: { h: 38, fs: 14, px: 14, r: 12 }, md: { h: 50, fs: 15.5, px: 18, r: 15 }, lg: { h: 56, fs: 16.5, px: 22, r: 17 } };
  const s = sizes[size];
  const variants = {
    primary: { background: T.accent, color: T.onAccent, border: '1px solid transparent', boxShadow: disabled ? 'none' : T.shadow.sm },
    soft:    { background: T.accentSoft, color: T.accent, border: '1px solid transparent' },
    ghost:   { background: 'transparent', color: T.ink, border: `1px solid ${T.line}` },
    quiet:   { background: T.surface2, color: T.sub, border: '1px solid transparent' },
    danger:  { background: T.status.out.soft, color: T.status.out.color, border: '1px solid transparent' },
  };
  return (
    <button
      onClick={disabled ? undefined : onClick}
      onPointerDown={() => setPress(true)}
      onPointerUp={() => setPress(false)}
      onPointerLeave={() => setPress(false)}
      style={{
        height: s.h, padding: `0 ${s.px}px`, borderRadius: s.r,
        font: `600 ${s.fs}px/1 var(--f)`, letterSpacing: '0.01em',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        cursor: disabled ? 'default' : 'pointer', width: full ? '100%' : undefined,
        opacity: disabled ? 0.45 : 1, userSelect: 'none', whiteSpace: 'nowrap',
        transition: 'transform .14s cubic-bezier(.2,.8,.2,1), background .2s, box-shadow .2s',
        transform: press && !disabled ? 'scale(0.965)' : 'scale(1)',
        ...variants[variant], ...style,
      }}>
      {icon && <Icon name={icon} size={size === 'sm' ? 17 : 19} />}
      {children}
    </button>
  );
}

function Thumb({ icon = 'box', tint, size = 46, radius = 14, image }) {
  const T = useTheme();
  const c = tint || T.accent;
  if (image) {
    return (
      <div style={{ width: size, height: size, borderRadius: radius, flexShrink: 0, overflow: 'hidden',
        background: T.surface2, border: `1px solid ${T.lineSoft}` }}>
        <img src={image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
      </div>
    );
  }
  return (
    <div style={{
      width: size, height: size, borderRadius: radius, flexShrink: 0,
      display: 'grid', placeItems: 'center', color: c, position: 'relative', overflow: 'hidden',
      background: T.surface2, border: `1px solid ${T.lineSoft}`,
    }}>
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.5,
        background: `repeating-linear-gradient(45deg, ${T.surface2}, ${T.surface2} 5px, color-mix(in oklch, ${c} 8%, transparent) 5px, color-mix(in oklch, ${c} 8%, transparent) 10px)`,
      }} />
      <div style={{ position: 'relative', zIndex: 1 }}><Icon name={icon} size={size * 0.5} stroke={1.6} /></div>
    </div>
  );
}

function StatusDot({ status, withLabel }) {
  const T = useTheme();
  const st = T.status[status] || T.status.ok;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span style={{ width: 8, height: 8, borderRadius: 99, background: st.color, boxShadow: `0 0 0 3px ${st.soft}` }} />
      {withLabel && <span style={{ font: `600 12.5px/1 var(--f)`, color: st.color, whiteSpace: 'nowrap' }}>{st.label}</span>}
    </span>
  );
}

// stock level bar — qty vs comfortable (min*2 floor 3)
function StockBar({ qty, min, status, animate = true }) {
  const T = useTheme();
  const st = T.status[status] || T.status.ok;
  const comfortable = Math.max(min * 2, min + 3, qty, 1);
  const pct = Math.max(0, Math.min(1, qty / comfortable));
  const minPct = Math.max(0, Math.min(1, min / comfortable));
  const [w, setW] = React.useState(animate ? 0 : pct);
  React.useEffect(() => { const r = requestAnimationFrame(() => setW(pct)); return () => cancelAnimationFrame(r); }, [pct]);
  return (
    <div style={{ position: 'relative', height: 8, borderRadius: 99, background: T.surface2, overflow: 'visible' }}>
      <div style={{ position: 'absolute', inset: 0, borderRadius: 99, overflow: 'hidden' }}>
        <div style={{
          width: `${w * 100}%`, height: '100%', borderRadius: 99,
          background: status === 'ok' ? T.accent : st.color,
          transition: 'width .7s cubic-bezier(.2,.8,.2,1)',
        }} />
      </div>
      {/* min threshold marker */}
      <div style={{
        position: 'absolute', top: -3, bottom: -3, left: `${minPct * 100}%`, width: 2,
        background: T.faint, borderRadius: 2, opacity: 0.5,
      }} />
    </div>
  );
}

// segmented control
function Seg({ value, options, onChange }) {
  const T = useTheme();
  return (
    <div style={{ display: 'flex', gap: 3, padding: 3, background: T.surface2, borderRadius: 13, border: `1px solid ${T.lineSoft}` }}>
      {options.map(o => {
        const active = o.value === value;
        return (
          <button key={o.value} onClick={() => onChange(o.value)} style={{
            flex: 1, height: 34, borderRadius: 10, border: 'none', cursor: 'pointer',
            font: `600 13px/1 var(--f)`, gap: 6, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            background: active ? T.surface : 'transparent', color: active ? T.ink : T.faint,
            boxShadow: active ? T.shadow.sm : 'none', transition: 'all .18s',
          }}>{o.icon && <Icon name={o.icon} size={15} />}{o.label}</button>
        );
      })}
    </div>
  );
}

// quantity stepper with bounce
function Stepper({ value, onChange, min = 1, max = 99, unit }) {
  const T = useTheme();
  const [bump, setBump] = React.useState(0);
  const set = (v) => { const nv = Math.max(min, Math.min(max, v)); if (nv !== value) { onChange(nv); setBump(b => b + 1); } };
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
      <RoundBtn icon="minus" onClick={() => set(value - 1)} disabled={value <= min} />
      <div style={{ textAlign: 'center', minWidth: 92 }}>
        <div key={bump} style={{
          font: `700 52px/1 var(--f)`, color: T.ink, fontFeatureSettings: '"tnum"',
          animation: 'numPop .28s cubic-bezier(.2,1.4,.3,1)',
        }}>{value}</div>
        {unit && <div style={{ font: `500 13px/1 var(--f)`, color: T.faint, marginTop: 6 }}>{unit}</div>}
      </div>
      <RoundBtn icon="plus" onClick={() => set(value + 1)} disabled={value >= max} />
    </div>
  );
}

function RoundBtn({ icon, onClick, disabled, accent }) {
  const T = useTheme();
  const [press, setPress] = React.useState(false);
  return (
    <button onClick={disabled ? undefined : onClick}
      onPointerDown={() => setPress(true)} onPointerUp={() => setPress(false)} onPointerLeave={() => setPress(false)}
      style={{
        width: 58, height: 58, borderRadius: 99, flexShrink: 0,
        border: `1px solid ${T.line}`, background: accent ? T.accent : T.surface,
        color: accent ? T.onAccent : T.ink, cursor: disabled ? 'default' : 'pointer',
        display: 'grid', placeItems: 'center', opacity: disabled ? 0.4 : 1,
        boxShadow: T.shadow.sm, transition: 'transform .14s cubic-bezier(.2,.8,.2,1)',
        transform: press && !disabled ? 'scale(0.9)' : 'scale(1)',
      }}>
      <Icon name={icon} size={24} stroke={2} />
    </button>
  );
}

// bottom sheet / modal
function Sheet({ open, onClose, children, title, maxW = 460, z = 200 }) {
  const T = useTheme();
  const [show, setShow] = React.useState(false);
  React.useEffect(() => {
    if (open) {
      const r = requestAnimationFrame(() => setShow(true));
      const t = setTimeout(() => setShow(true), 60); // fallback if rAF is throttled (e.g. backgrounded tab)
      return () => { cancelAnimationFrame(r); clearTimeout(t); };
    }
    setShow(false);
  }, [open]);
  if (!open) return null;
  return (
    <div onClick={onClose} style={{
      position: 'absolute', inset: 0, zIndex: z, display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      background: show ? 'rgba(30,24,20,0.35)' : 'rgba(30,24,20,0)', transition: 'background .3s',
      backdropFilter: show ? 'blur(2px)' : 'none',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', maxWidth: maxW, background: T.surface, borderRadius: '26px 26px 0 0',
        boxShadow: T.shadow.pop, padding: '10px 22px calc(22px + env(safe-area-inset-bottom))',
        transform: show ? 'translateY(0)' : 'translateY(100%)',
        transition: 'transform .42s cubic-bezier(.2,.9,.25,1)',
        maxHeight: '92%', overflowY: 'auto',
      }}>
        <div style={{ width: 40, height: 5, borderRadius: 99, background: T.line, margin: '0 auto 14px' }} />
        {title && <div style={{ font: `700 19px/1.2 var(--f)`, color: T.ink, marginBottom: 18 }}>{title}</div>}
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  TONES, STATUS, makeTheme, ThemeCtx, useTheme, UserCtx, useUser,
  Icon, Btn, Thumb, StatusDot, StockBar, Seg, Stepper, RoundBtn, Sheet,
});
