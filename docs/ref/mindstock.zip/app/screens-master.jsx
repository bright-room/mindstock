// screens-master.jsx — per-household product master (商品マスタ): owner-only edit screen,
// unit picker, image field, delete-with-warning. Root master lives in CATALOG; households adopt from it.

const COMMON_UNITS = ['個', '本', '袋', 'パック', '箱', 'ロール', '缶', '枚', 'セット'];

// unit chooser: common chips + free-text "other"
function UnitPicker({ value, onChange }) {
  const T = useTheme();
  const custom = value && !COMMON_UNITS.includes(value);
  return (
    <div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {COMMON_UNITS.map(u => {
          const active = value === u;
          return (
            <button key={u} onClick={() => onChange(u)} style={{
              font: `600 13.5px/1 var(--f)`, padding: '10px 14px', borderRadius: 99, cursor: 'pointer',
              border: `1.5px solid ${active ? T.accent : T.line}`, background: active ? T.accentSoft : T.surface, color: active ? T.accent : T.sub }}>{u}</button>
          );
        })}
      </div>
      <input value={custom ? value : ''} onChange={e => onChange(e.target.value)} placeholder="その他（自由入力）"
        style={{ marginTop: 10, width: '100%', height: 44, borderRadius: 12, border: `1px solid ${custom ? T.accent : T.line}`,
          background: T.surface, padding: '0 14px', font: `500 14px/1 var(--f)`, color: T.ink, outline: 'none', boxSizing: 'border-box' }} />
    </div>
  );
}

// image upload field with preview + icon fallback
function ImageField({ image, icon, onChange }) {
  const T = useTheme();
  const ref = React.useRef(null);
  const onFile = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => onChange(r.result);
    r.readAsDataURL(f);
    e.target.value = '';
  };
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <Thumb icon={icon} image={image} size={64} radius={16} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn size="sm" variant="soft" icon="plus" onClick={() => ref.current && ref.current.click()}>{image ? '画像を変更' : '画像を追加'}</Btn>
          {image && <Btn size="sm" variant="ghost" icon="trash" onClick={() => onChange(null)}>削除</Btn>}
        </div>
        <div style={{ font: `400 11.5px/1.4 var(--f)`, color: T.faint, marginTop: 8 }}>正方形がおすすめ。未設定ならアイコンを表示します。</div>
      </div>
      <input ref={ref} type="file" accept="image/*" onChange={onFile} style={{ display: 'none' }} />
    </div>
  );
}

// edit one master item: image + unit + 最低在庫, or archive (reversible)
function MasterItemSheet({ open, product, onClose, onSetUnit, onSetImage, onSetMin, onArchive, z = 200 }) {
  const T = useTheme();
  const [unit, setUnit] = React.useState('');
  const [img, setImg] = React.useState(null);
  const [min, setMin] = React.useState(1);
  React.useEffect(() => { if (open && product) { setUnit(product.unit); setImg(product.image || null); setMin(product.min); } }, [open, product && product.id]);
  if (!product) return null;
  const changed = unit !== product.unit || img !== (product.image || null);
  const save = () => {
    if (unit.trim() && unit !== product.unit) onSetUnit(product.id, unit.trim());
    if (img !== (product.image || null)) onSetImage(product.id, img);
    onClose();
  };
  const setMinNow = (v) => { const nv = Math.max(0, v); setMin(nv); onSetMin(product.id, nv); };
  return (
    <Sheet open={open} onClose={onClose} title="商品マスタの編集" z={z}>
      <div style={{ font: `700 16.5px/1.3 var(--f)`, color: T.ink }}>{product.name}</div>
      <div style={{ font: `400 12px/1.4 var(--f)`, color: T.faint, margin: '6px 0 18px' }}>商品名は変更できません。</div>

      <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 2px 10px' }}>画像</div>
      <div style={{ marginBottom: 22 }}><ImageField image={img} icon={product.icon} onChange={setImg} /></div>

      <div style={{ font: `600 12px/1 var(--f)`, color: T.faint, margin: '0 2px 10px' }}>数える単位</div>
      <div style={{ marginBottom: 22 }}><UnitPicker value={unit} onChange={setUnit} /></div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 0', borderTop: `1px solid ${T.lineSoft}`, borderBottom: `1px solid ${T.lineSoft}`, marginBottom: 22 }}>
        <div>
          <div style={{ font: `600 14.5px/1 var(--f)`, color: T.ink }}>最低在庫</div>
          <div style={{ font: `500 12px/1.3 var(--f)`, color: T.faint, marginTop: 5 }}>これ以下になると買い物リストへ</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={() => setMinNow(min - 1)} style={miniStepM(T)}><Icon name="minus" size={18} /></button>
          <span style={{ font: `700 22px/1 var(--f)`, color: T.ink, minWidth: 26, textAlign: 'center', fontFeatureSettings: '"tnum"' }}>{min}</span>
          <button onClick={() => setMinNow(min + 1)} style={miniStepM(T)}><Icon name="plus" size={18} /></button>
        </div>
      </div>

      <Btn full size="lg" disabled={!changed || !unit.trim()} onClick={save}>変更を保存</Btn>

      <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${T.lineSoft}` }}>
        {product.qty > 0 ? (
          <React.Fragment>
            <Btn full variant="quiet" icon="archive" disabled>この商品をアーカイブ</Btn>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginTop: 12, padding: '11px 13px', borderRadius: T.radius.md, background: T.surface2 }}>
              <Icon name="box" size={16} style={{ color: T.faint, flexShrink: 0, marginTop: 1 }} />
              <span style={{ font: `500 12px/1.5 var(--f)`, color: T.sub }}>在庫が <b style={{ color: T.ink }}>{product.qty}{product.unit}</b> 残っています。アーカイブは在庫が <b style={{ color: T.ink }}>0{product.unit}</b> のときだけできます。先に使い切ってください。</span>
            </div>
          </React.Fragment>
        ) : (
          <React.Fragment>
            <Btn full variant="quiet" icon="archive" onClick={() => { onArchive(product.id); onClose(); }}>この商品をアーカイブ</Btn>
            <div style={{ font: `400 11.5px/1.6 var(--f)`, color: T.faint, textAlign: 'center', marginTop: 12 }}>
              在庫一覧・買い物リストから外れますが、記録も設定も残ります。<br />「アーカイブした商品」からいつでも在庫に戻せます。
            </div>
          </React.Fragment>
        )}
      </div>
    </Sheet>
  );
}

function miniStepM(T) {
  return { width: 40, height: 40, borderRadius: 11, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer' };
}

// owner-only full-screen master manager (slide-in)
function MasterScreen({ open, onClose, store, onAdd }) {
  const T = useTheme();
  const [sel, setSel] = React.useState(null);
  React.useEffect(() => { if (!open) setSel(null); }, [open]);
  if (!open) return null;
  const products = store.products;
  const liveSel = sel ? store.allProducts.find(p => p.id === sel.id) || null : null;
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 215, background: T.bg,
      display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 20px 6px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={onClose} style={{ width: 40, height: 40, borderRadius: 12, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer', flexShrink: 0 }}>
          <Icon name="chevL" size={20} />
        </button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: `700 18px/1 var(--f)`, color: T.ink }}>商品マスタ</div>
          <div style={{ font: `500 11.5px/1 var(--f)`, color: T.faint, marginTop: 5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{store.active ? store.active.name : ''} · {products.length}品目</div>
        </div>
      </div>

      <div className="scroller" style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 28px' }}>
        <button onClick={onAdd} style={{ width: '100%', height: 54, borderRadius: T.radius.lg, border: `1.5px dashed ${T.accent}`,
          background: T.surface, color: T.accent, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, font: `700 14.5px/1 var(--f)`, marginBottom: 16 }}>
          <Icon name="plus" size={19} />商品を追加
        </button>
        <div style={{ font: `500 12px/1.55 var(--f)`, color: T.faint, margin: '0 2px 14px' }}>各商品の画像と「数える単位」を設定できます。タップして編集。</div>

        {products.length === 0 ? (
          <EmptyState icon="box" title="まだ商品がありません" sub="「商品を追加」から大元のマスタを選んで採用しましょう。" />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {products.map(p => (
              <button key={p.id} onClick={() => setSel(p)} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: 12, borderRadius: T.radius.md, cursor: 'pointer',
                border: `1px solid ${T.lineSoft}`, background: T.surface, boxShadow: T.shadow.sm, textAlign: 'left' }}>
                <Thumb icon={p.icon} image={p.image} size={46} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `600 14.5px/1.3 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                  <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginTop: 5 }}>単位: {p.unit} · 在庫 {p.qty}{p.unit}</div>
                </div>
                <Icon name="pencil" size={16} style={{ color: T.faint, flexShrink: 0 }} />
              </button>
            ))}
          </div>
        )}

        {/* アーカイブの閲覧・復元は「設定 → アーカイブした商品」へ */}
      </div>

      <MasterItemSheet open={!!liveSel} product={liveSel} onClose={() => setSel(null)}
        onSetUnit={store.setUnit} onSetImage={store.setImage} onSetMin={store.setMin}
        onArchive={(id) => { store.archive(id); setSel(null); }} />
    </div>
  );
}

// アーカイブした商品の一覧（閲覧は誰でも・復元はオーナーのみ）
function ArchivedScreen({ open, onClose, store, canRestore }) {
  const T = useTheme();
  if (!open) return null;
  const archived = store.archivedProducts;
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 216, background: T.bg, display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 20px 6px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={onClose} style={{ width: 40, height: 40, borderRadius: 12, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer', flexShrink: 0 }}>
          <Icon name="chevL" size={20} />
        </button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: `700 18px/1 var(--f)`, color: T.ink }}>アーカイブした商品</div>
          <div style={{ font: `500 11.5px/1 var(--f)`, color: T.faint, marginTop: 5 }}>{store.active ? store.active.name : ''} · {archived.length}件</div>
        </div>
      </div>

      <div className="scroller" style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 28px' }}>
        <div style={{ font: `500 12px/1.6 var(--f)`, color: T.faint, margin: '0 2px 16px' }}>
          いったん使うのをやめた商品。記録と設定はそのまま残っています。{canRestore ? 'また必要になったら「在庫に戻す」。' : '在庫に戻せるのはオーナーです。'}
        </div>

        {archived.length === 0 ? (
          <EmptyState icon="archive" title="アーカイブした商品はありません" sub="商品マスタの編集からアーカイブすると、ここに集まります。" />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {archived.map(p => (
              <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: 12, borderRadius: T.radius.md,
                border: `1px solid ${T.lineSoft}`, background: T.surface }}>
                <div style={{ opacity: 0.7, flexShrink: 0 }}><Thumb icon={p.icon} image={p.image} size={46} /></div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: `600 14.5px/1.3 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                  <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginTop: 5 }}>単位: {p.unit} · 最低 {p.min}{p.unit}</div>
                </div>
                {canRestore && <Btn size="sm" variant="soft" icon="swap" onClick={() => store.unarchive(p.id)}>在庫に戻す</Btn>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { COMMON_UNITS, UnitPicker, ImageField, MasterItemSheet, MasterScreen, ArchivedScreen });
