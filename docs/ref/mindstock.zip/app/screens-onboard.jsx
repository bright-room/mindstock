// screens-onboard.jsx — first-login workflow: display name → create household

function Onboard({ onComplete, onSkip, onCancel }) {
  const T = useTheme();
  const [step, setStep] = React.useState(0); // 0 welcome, 1 name, 2 household, 3 confirm
  const [name, setName] = React.useState('');
  const [house, setHouse] = React.useState('');
  const [creating, setCreating] = React.useState(false);
  const formSteps = 2; // name, household (for progress)

  const go = (n) => setStep(n);
  const finish = () => { setCreating(true); setTimeout(() => onComplete(name.trim(), house.trim()), 750); };

  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', background: `linear-gradient(180deg, ${T.bg}, ${T.bgDeep})` }}>
      {/* top bar: back + progress */}
      <div style={{ padding: '52px 24px 6px', display: 'flex', alignItems: 'center', gap: 14, minHeight: 56 }}>
        {step > 0 && step < 3 && (
          <button onClick={() => go(step - 1)} style={{ width: 38, height: 38, borderRadius: 12, border: `1px solid ${T.line}`, background: T.surface, color: T.ink, display: 'grid', placeItems: 'center', cursor: 'pointer', flexShrink: 0 }}>
            <Icon name="chevL" size={19} />
          </button>
        )}
        {step >= 1 && step <= 2 && (
          <div style={{ display: 'flex', gap: 7, flex: 1, alignItems: 'center' }}>
            {Array.from({ length: formSteps }).map((_, i) => (
              <div key={i} style={{ flex: 1, height: 5, borderRadius: 99, background: i < step ? T.accent : T.line, transition: 'background .3s' }} />
            ))}
          </div>
        )}
        {step >= 1 && step <= 2 && (
          <span style={{ font: `600 12.5px/1 var(--f)`, color: T.faint, flexShrink: 0 }}>{step} / {formSteps}</span>
        )}
      </div>

      <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <StepPane key={step}>
          {step === 0 && <WelcomeStep T={T} onStart={() => go(1)} />}
          {step === 1 && (
            <FormStep T={T} icon="user" eyebrow="プロフィール" title="お名前を教えてください"
              sub="補充や消費の記録に表示され、家族にも見えます。あとから変更できます。"
              value={name} onChange={setName} placeholder="例: たろう" max={100} active />
          )}
          {step === 2 && (
            <FormStep T={T} icon="home" eyebrow="世帯をつくる（任意）" title="世帯に名前をつけましょう"
              sub="在庫を共有する単位です。まずはあなた1人から。あとで家族を招待できます。今は決めなくても大丈夫です。"
              value={house} onChange={setHouse} placeholder="例: わたしの家" max={50} active
              chips={['わたしの家', '田中家', '自宅']} onChip={setHouse} />
          )}
          {step === 3 && <ConfirmStep T={T} name={name} house={house} creating={creating} />}
        </StepPane>
      </div>

      {/* footer action */}
      <div style={{ padding: '14px 24px calc(26px + env(safe-area-inset-bottom))' }}>
        {step === 0 && (
          <React.Fragment>
            <Btn full size="lg" onClick={() => go(1)}>はじめる</Btn>
            <button onClick={onCancel} style={{ width: '100%', marginTop: 12, background: 'none', border: 'none', color: T.faint, font: `500 13px/1 var(--f)`, cursor: 'pointer' }}>別のアカウントでログイン</button>
          </React.Fragment>
        )}
        {step === 1 && (
          <Btn full size="lg" disabled={!name.trim()} onClick={() => go(2)}>次へ</Btn>
        )}
        {step === 2 && (
          <React.Fragment>
            <Btn full size="lg" disabled={!house.trim()} onClick={() => go(3)}>確認する</Btn>
            <button onClick={() => onSkip(name.trim())} style={{ width: '100%', marginTop: 12, background: 'none', border: 'none', color: T.faint, font: `600 13px/1 var(--f)`, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
              あとで設定する（スキップ）<Icon name="chevR" size={15} />
            </button>
          </React.Fragment>
        )}
        {step === 3 && (
          <React.Fragment>
            <Btn full size="lg" disabled={creating} onClick={finish}>{creating ? '作成中…' : 'mindstock を始める'}</Btn>
            <button onClick={() => go(2)} disabled={creating} style={{ width: '100%', marginTop: 12, background: 'none', border: 'none', color: T.faint, font: `500 13px/1 var(--f)`, cursor: creating ? 'default' : 'pointer' }}>修正する</button>
          </React.Fragment>
        )}
      </div>
    </div>
  );
}

function StepPane({ children }) {
  return <div style={{ height: '100%', overflowY: 'auto' }}>{children}</div>;
}

function WelcomeStep({ T, onStart }) {
  return (
    <div style={{ padding: '24px 28px', display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 22 }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', boxShadow: T.shadow.md, transform: 'rotate(-6deg)' }}>
        <Icon name="box" size={34} stroke={1.8} />
      </div>
      <div>
        <div style={{ font: `800 26px/1.25 var(--f)`, color: T.ink, letterSpacing: '-0.02em' }}>ようこそ、<br />mindstock へ</div>
        <p style={{ font: `400 15px/1.7 var(--f)`, color: T.sub, marginTop: 14, maxWidth: 300 }}>
          はじめに、かんたんな初期設定をします。<b style={{ color: T.ink }}>表示名</b>を決めれば準備完了。<b style={{ color: T.ink }}>世帯</b>はあとからでもつくれます。
        </p>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 4 }}>
        {[{ i: 'user', t: '表示名を決める', s: '記録に残る名前' }, { i: 'home', t: '世帯をつくる', s: '任意・あとでもOK' }].map((x, n) => (
          <div key={x.t} style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: T.surface, border: `1px solid ${T.line}`, color: T.accent, display: 'grid', placeItems: 'center', position: 'relative' }}>
              <Icon name={x.i} size={19} />
              <span style={{ position: 'absolute', top: -6, left: -6, width: 19, height: 19, borderRadius: 99, background: T.accent, color: T.onAccent, font: `700 10px/1 var(--f)`, display: 'grid', placeItems: 'center' }}>{n + 1}</span>
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{ font: `600 14px/1.2 var(--f)`, color: T.ink, whiteSpace: 'nowrap' }}>{x.t}</div>
              <div style={{ font: `500 12px/1.2 var(--f)`, color: T.faint, marginTop: 3, whiteSpace: 'nowrap' }}>{x.s}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FormStep({ T, icon, eyebrow, title, sub, value, onChange, placeholder, max, active, chips, onChip }) {
  return (
    <div style={{ padding: '20px 28px', display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ width: 52, height: 52, borderRadius: 16, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center' }}>
        <Icon name={icon} size={26} />
      </div>
      <div>
        <div style={{ font: `600 12.5px/1 var(--f)`, color: T.accent, marginBottom: 9 }}>{eyebrow}</div>
        <div style={{ font: `800 22px/1.3 var(--f)`, color: T.ink, letterSpacing: '-0.01em' }}>{title}</div>
        <p style={{ font: `400 14px/1.6 var(--f)`, color: T.sub, marginTop: 11 }}>{sub}</p>
      </div>
      <div>
        <input value={value} maxLength={max} onChange={e => onChange(e.target.value)} placeholder={placeholder}
          style={{ width: '100%', height: 56, borderRadius: 16, border: `1.5px solid ${value ? T.accent : T.line}`, background: T.surface,
            padding: '0 18px', font: `600 17px/1 var(--f)`, color: T.ink, boxSizing: 'border-box', outline: 'none', boxShadow: T.shadow.sm, transition: 'border-color .2s' }} />
        <div style={{ display: 'flex', justifyContent: 'flex-end', font: `500 11.5px/1 var(--f)`, color: T.faint, marginTop: 8 }}>{value.length} / {max}</div>
        {chips && (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
            {chips.map(c => (
              <button key={c} onClick={() => onChip(c)} style={{ font: `600 13px/1 var(--f)`, color: T.sub, background: T.surface, border: `1px solid ${T.line}`, padding: '9px 13px', borderRadius: 99, cursor: 'pointer', whiteSpace: 'nowrap' }}>{c}</button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ConfirmStep({ T, name, house, creating }) {
  return (
    <div style={{ padding: '20px 28px', display: 'flex', flexDirection: 'column', gap: 22, justifyContent: 'center', height: '100%' }}>
      <div>
        <div style={{ font: `600 12.5px/1 var(--f)`, color: T.accent, marginBottom: 9 }}>最終確認</div>
        <div style={{ font: `800 22px/1.3 var(--f)`, color: T.ink }}>この内容で始めます</div>
      </div>
      <div style={{ background: T.surface, borderRadius: T.radius.lg, border: `1px solid ${T.lineSoft}`, boxShadow: T.shadow.sm, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 18 }}>
          <span style={{ width: 48, height: 48, borderRadius: 99, background: T.accent, color: T.onAccent, display: 'grid', placeItems: 'center', font: `700 20px/1 var(--f)`, flexShrink: 0 }}>{(name || 'あ')[0]}</span>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginBottom: 5 }}>表示名</div>
            <div style={{ font: `700 16px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name || '—'}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 18, borderTop: `1px solid ${T.lineSoft}` }}>
          <span style={{ width: 48, height: 48, borderRadius: 14, background: T.accentSoft, color: T.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}><Icon name="home" size={24} /></span>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ font: `500 12px/1 var(--f)`, color: T.faint, marginBottom: 5 }}>世帯</div>
            <div style={{ font: `700 16px/1.2 var(--f)`, color: T.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{house || '—'}</div>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, font: `500 12.5px/1.5 var(--f)`, color: T.faint }}>
        <Icon name="check" size={16} style={{ color: T.status.ok.color, flexShrink: 0 }} />
        <span>あなたが世帯のオーナーになります。家族の招待は設定からいつでも。</span>
      </div>
    </div>
  );
}

Object.assign(window, { Onboard });
